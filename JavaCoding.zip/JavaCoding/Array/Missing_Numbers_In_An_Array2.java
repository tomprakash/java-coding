package Array;

public class Missing_Numbers_In_An_Array2 {

	public static void main(String[] args) {
		int arr[] = { 1, 3, 5, 7, 9 };
		findMissingNumbers(arr, 9);

	}

	public static void findMissingNumbers(int arr[], int n) {

		int j = arr[0];
		for (int i = 0; i < arr.length; i++) {
			if (j == arr[i]) {
				j++;
			} else {
				System.out.println(j);
				i--;
				j++;
			}
		}

	}
}
