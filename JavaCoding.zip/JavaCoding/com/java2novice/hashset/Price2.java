package com.java2novice.hashset;

class Price2{
     
    private String item;
    private int Price2;
     
    public Price2(String itm, int pr){
        this.item = itm;
        this.Price2 = pr;
    }
     
    public int hashCode(){
        System.out.println("In hashcode");
        int hashcode = 0;
        hashcode = Price2*20;
        hashcode += item.hashCode();
        return hashcode;
    }
     
    public boolean equals(Object obj){
        System.out.println("In equals");
        if (obj instanceof Price2) {
            Price2 pp = (Price2) obj;
            return (pp.item.equals(this.item) && pp.Price2 == this.Price2);
        } else {
            return false;
        }
    }
     
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public int getPrice2() {
        return Price2;
    }
    public void setPrice2(int Price2) {
        this.Price2 = Price2;
    }
     
    public String toString(){
        return "item: "+item+"  Price2: "+Price2;
    }
}
