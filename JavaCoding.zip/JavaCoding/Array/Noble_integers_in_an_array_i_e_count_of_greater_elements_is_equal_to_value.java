package Array;
//https://www.geeksforgeeks.org/noble-integers-in-an-array-count-of-greater-elements-is-equal-to-value/

public class Noble_integers_in_an_array_i_e_count_of_greater_elements_is_equal_to_value {

	public static void main(String[] args) {

		int arr[] = { 1, -3, 4, 0, -1 };
		int n = 4;
		if (nobleIntegers(arr, n))
			System.out.println("Yes");
		else
			System.out.println("No");
	}

	public static boolean nobleIntegers(int arr[], int n) {
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] < n)
				count++;
		}
		if (count == n)
			return true;
		return false;
	}

}
