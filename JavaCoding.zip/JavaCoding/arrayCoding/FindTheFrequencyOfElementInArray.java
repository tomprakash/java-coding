package arrayCoding;

import java.util.Scanner;

public class FindTheFrequencyOfElementInArray {

	public static void main(String args[]) {
		int array[] = { 1, 2, 3, 3, 4, 5 };
		int i, a, f = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the element to find the frequency");
		a = sc.nextInt();
		for (i = 0; i < array.length; i++)

		{
			if (a == array[i])
				f++;
		}

		System.out.println("the frequency of element " + a + " is " + f);
	}

}
