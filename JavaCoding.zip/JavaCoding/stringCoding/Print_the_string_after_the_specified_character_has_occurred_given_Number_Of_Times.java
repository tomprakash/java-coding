package stringCoding;

public class Print_the_string_after_the_specified_character_has_occurred_given_Number_Of_Times {

	public static void main(String[] args) {
		String str = "Geek for Geeks coding";
		findsubstr(str, 'e', 3);
	}

	public static void findsubstr(String str, char ch, int count) {
		int occ = 0, i;

		if (count == 0) {
			System.out.println(str);
			return;
		}
		for (i = 0; i < str.length(); i++) {
			if (str.charAt(i) == ch)
				occ++;

			if (occ == count)
				break;
		}
		if (i < str.length() - 1)

			System.out.println(str.substring(i + 1));
		else
			System.out.println("empty string");
	}
}
