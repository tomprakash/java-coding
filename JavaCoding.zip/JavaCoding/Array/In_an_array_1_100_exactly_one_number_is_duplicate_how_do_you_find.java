package Array;

public class In_an_array_1_100_exactly_one_number_is_duplicate_how_do_you_find {

	public static void exactly_one_duplicate(int arr[]) {

		int n = arr.length;
		int sum = n * (n - 1) / 2;
		int sum1 = 0;

		for (int i = 0; i < n; i++) {

			sum1 = sum1 + arr[i];
		}

		System.out.println("duplicate number is " + (sum1 - sum));
	}

	public static void main(String arg[]) {

		int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1 };

		exactly_one_duplicate(arr);

	}

}
