package Array;
//https://www.geeksforgeeks.org/a-sum-array-puzzle/

public class A_Sum_Array_Puzzle {

	public static void main(String[] args) {

		int arr[] = { 3, 6, 4, 8, 9 };
		sumArray(arr);
	}

	public static void sumArray(int arr[]) {
		int[] res = new int[arr.length];

		for (int i = 0; i < arr.length; i++) {
			res[i] = 0;
			for (int j = 0; j < arr.length; j++) {
				if (i != j) {
					res[i] = res[i] + arr[j];
				}
			}
		}

		for (int ele : res) {
			System.out.print(ele + ",");
		}
	}
}
