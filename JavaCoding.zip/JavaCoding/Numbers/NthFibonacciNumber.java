package Numbers;

public class NthFibonacciNumber {

	public static void main(String[] args) {
		int n = 9;
		System.out.println(n +" th "+ "fibonacci number is "+findNthFibonacci(n));
	}

	public static int findNthFibonacci(int n) {
		int a = 0, b = 0, c = 1;
		for (int i = 0; i < 9; i++) {
			a = b;
			b = c;
			c = a + b;
			System.out.println(a);
		}
		return a;
	}
}