package Array;

public class Remove_an_Element_at_specific_index_from_an_Array_in_Java {

	public static void Remove_an_Element_at_specific_index(int arr[], int index) {

		int newarr[] = new int[arr.length - 1];
		for (int i = 0; i < arr.length; i++) {

			if (i == index) {
				newarr[i] = arr[++i];
			}
			else{
				newarr[i]=arr[i];
			}
		}
		
		for(int i=0;i<newarr.length;i++){
			System.out.println(newarr[i]);
		}
	}

	public static void main(String[] args) {
		int arr[] = { 1, 2, 3, 4, 5 };
		Remove_an_Element_at_specific_index(arr,3);
	}
}
