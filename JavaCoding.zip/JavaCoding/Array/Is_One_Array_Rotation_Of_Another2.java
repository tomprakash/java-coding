package Array;

public class Is_One_Array_Rotation_Of_Another2 {

	public static boolean One_Array_Rotation_Of_Another(int arr1[], int arr2[]) {

		String str1 = "";
		String str2 = "";
		for (int i = 0; i < arr1.length; i++) {
			str1 = str1 + arr1[i];
		}
		for (int i = 0; i < arr2.length; i++) {
			str2 = str2 + arr2[i];
		}
		str1 = str1 + str1;
		if (str1.indexOf(str2) == -1)
			return false;
		return true;
	}

	public static void main(String[] args) {

		int arr1[] = { 1, 2, 3, 4, 5 };
		int arr2[] = { 2, 3, 4, 5, 1 };
		System.out.println(One_Array_Rotation_Of_Another(arr1, arr2));
	}
}
