package Numbers;

public class Sum_of_Fibonacci_series {

	public static int Find_Sum_of_Fibonacci_series(int n) {
		int a = 0, b = 0, c = 1, sum = 0;
		for (int i = 0; i < n; i++) {

			a = b;
			b = c;
			c = a + b;
			System.out.println(a);
			sum = sum + a;
		}
		return sum;

	}

	public static void main(String[] args) {

		System.out.println(Find_Sum_of_Fibonacci_series(7));
	}

}
