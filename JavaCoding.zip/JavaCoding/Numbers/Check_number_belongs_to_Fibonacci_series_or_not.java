package Numbers;

public class Check_number_belongs_to_Fibonacci_series_or_not {

	public static void main(String[] args) {

		int n = 55, a, b, c;
		a = b = 0;
		c = 1;

		while (a < n) {
			a = b;
			b = c;
			c = a + b;
		}
		if (a == n)
			System.out.println("Fibonacci number");
		else
			System.out.println("Not a fibonacci number");
	}

}
