package stringCoding;

public class SwaptwoString {

	public static void main(String[] args) {

		String str1 = "Tom";
		String str2 = "Prakash";

		System.out.println("before swap the strings are  " + str1 + " and " + str2);

		str1 = str1 + str2;

		str2 = str1.substring(0, str1.length() - str2.length());

		str1 = str1.substring(str2.length());
		System.out.println(str2.length());

		System.out.println("after swap the strings are  " + str1 + " and " + str2);
	}
}
