package Array;
//https://www.geeksforgeeks.org/number-of-unique-pairs-in-an-array/

//check link for the better solution

import java.util.HashSet;
import java.util.Set;

public class Number_of_unique_pairs_in_an_array {

	public static void main(String[] args) {

		int arr[] = { 1, 1, 2 };
		// Output:4 - (1, 1),(1, 2),(2, 1),(2, 2) are the only possible pairs.
		System.out.println(countUniquePairsInAnArray(arr));
	}

	public static int countUniquePairsInAnArray(int arr[]) {
		Set<Object> set = new HashSet<Object>();
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				System.out.println(arr[i] + "..." + arr[j]);
				set.add(arr[i] + "..." + arr[j]);
			}
		}
		return set.size();
	}
}
