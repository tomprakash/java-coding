package smartInterviews.array;

public class Mini_Max_Sum {

	public static void main(String[] args) {

		int arr[] = { 1, 3, 5, 7, 9 };

		miniMaxSum(arr);

	}

	static void miniMaxSum(int[] arr) {
		int min = Integer.MAX_VALUE;
		int max = Integer.MIN_VALUE;
		int sum = 0;
		int value = 0;
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}

		for (int i = 0; i < arr.length; i++) {

			value = sum - arr[i];

			if (sum < min) {
				min = value;

			} else if (sum > max) {
				max = value;
			}
		}
		System.out.println("max " + min);
		System.out.println("min " + max);
	}
}
