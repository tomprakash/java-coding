package string;

import java.util.HashMap;
import java.util.Map.Entry;

public class remove_Given_Character_From_String {

	public static void givenCharacterFromString(String str) {

		StringBuffer strnew = new StringBuffer();
		char arr[] = str.toCharArray();
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();

		for (int i = 0; i < arr.length - 1; i++) {

			if (map.containsKey(arr[i]))
				map.put(arr[i], map.get(arr[i]) + 1);
			else
				map.put(arr[i], 0);
		}

		for (Entry<Character, Integer> entry : map.entrySet()) {
			strnew.append(entry.getKey());

		}
		System.out.println(strnew);

	}

	public static void main(String args[]) {

		givenCharacterFromString("asfgafdg");
	}
}
