package string;
//https://www.geeksforgeeks.org/palindrome-pair-in-an-array-of-words-or-strings/

public class Palindrome_pair_in_an_array_of_words {

	public static void main(String[] args) {

		String arr[] = { "geekfv", "geeks", "or", "vkeeg", "abc", "bc" };
		if (checkPalindromePair(arr) == true)
			System.out.println("Yes");
		else
			System.out.println("No");
	}

	static boolean checkPalindromePair(String arr[]) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				String pair = arr[i] + arr[j];
				System.out.println("pair " + pair);
				if (isPalindrome(pair))
					return true;
			}
		}
		return false;
	}

	public static boolean isPalindrome(String str) {

		int low = 0;
		int high = str.length() - 1;
		while (low < high) {

			if (str.charAt(low) != str.charAt(high))
				return false;
			low++;
			high--;
		}
		return true;
	}

}
