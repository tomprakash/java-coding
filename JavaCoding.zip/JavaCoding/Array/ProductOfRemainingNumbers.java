package Array;
//https://www.geeksforgeeks.org/a-product-array-puzzle/

public class ProductOfRemainingNumbers {

	public static void main(String[] args) {
		int[] arr = { 10, 3, 5, 6, 2 };
		productOfRemaining(arr);
	}

	static void productOfRemaining(int[] arr) {
		int[] res = new int[arr.length];

		for (int i = 0; i < arr.length; i++) {
			res[i] = 1;
			for (int j = 0; j < arr.length; j++) {
				if (i != j) {
					res[i] = res[i] * arr[j];
				}
			}
		}

		for (int ele : res) {
			System.out.print(ele + ",");
		}

	}
}
