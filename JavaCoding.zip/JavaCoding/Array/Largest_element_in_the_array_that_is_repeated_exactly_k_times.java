package Array;

import java.util.HashMap;
import java.util.Map.Entry;

public class Largest_element_in_the_array_that_is_repeated_exactly_k_times {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 5, 5, 3, 2 };

		int k = 2;

		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (int i = 0; i < arr.length; i++) {

			if (!map.containsKey(arr[i]))
				map.put(arr[i], 1);
			else
				map.put(arr[i], map.get(arr[i]) + 1);
		}
		System.out.println(map);
		System.out.println("k "+k);
		int max = Integer.MIN_VALUE;
		for (Entry<Integer, Integer> entry : map.entrySet()) {
			if (entry.getValue() == k) {
				if (entry.getKey() > max)
					max = entry.getKey();
			}
		}
		System.out.println(max);
	}

}
