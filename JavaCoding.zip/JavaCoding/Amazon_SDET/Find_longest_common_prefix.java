package Amazon_SDET;

public class Find_longest_common_prefix {

	public static String longest_common_prefix(String[] arr) {
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String arr[] = { "abcd", "abbd", "abdy", "az" };

		System.out.println(longest_common_prefix(arr));
	}

}
