package oracle;

public class CamelCaseWordCount {

	public static int CamelCaseWord(String str) {
		int count = 0;

		for (int i = 0; i < str.length(); i++) {

			if ((int) str.charAt(i) >= 65 && (int) str.charAt(i) <= 90)

				count++;
		}

		return count;

	}

	public static void main(String args[]) {
		System.out.println(CamelCaseWord("We are A New Team"));
	}
}
