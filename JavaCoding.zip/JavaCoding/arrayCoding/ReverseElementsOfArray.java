package arrayCoding;

import java.util.Scanner;

public class ReverseElementsOfArray {

	public static void main(String args[]) {
		int counter, i = 0, j = 0, temp;
		int tem[] = null;
		int number[] = new int[100];
		Scanner scanner = new Scanner(System.in);
		System.out.print("How many elements you want to enter: ");
		counter = scanner.nextInt();

		/*
		 * This loop stores all the elements that we enter in an the array
		 * number. First element is at number[0], second at number[1] and so on
		 */
		for (i = 0; i < counter; i++) {
			System.out.print("Enter Array Element" + (i + 1) + ": ");
			number[i] = scanner.nextInt();
		}
		int length = number.length;

		for (j = 0; j < length; j++) {
			tem[j] = number[length - 1];
			length--;

		}

		for (j = 0; j < tem.length; j++)

		{
			System.out.println(tem[j] + " ");
		}
	}
}
