package Numbers;

public class ArmStrong_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int number = 153;
		int n = number;
		int sum = 0;
		int r;
		while (n > 0) {

			r = n % 10;
			sum = sum + r * r * r;
			n = n / 10;
		}
		System.out.println("sum " + sum);
		System.out.println("n " + number);

		if (number == sum)
			System.out.println("number is armstrong");
		else
			System.out.println("number is not armstrong");

	}

}
