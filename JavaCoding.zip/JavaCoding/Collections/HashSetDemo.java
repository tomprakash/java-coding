package Collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetDemo {

    public static void main(String args[]) {

        // Creating and initializing an HashSet for iteration
        Set<String> setOfStocks = new HashSet<>();
        setOfStocks.add("INFY");
        setOfStocks.add("BABA");
        setOfStocks.add("GOOG");
        setOfStocks.add("MSFT");
        setOfStocks.add("AMZN");

        System.out.println("Set: " + setOfStocks);

        // Example 1 - iterating over HashSet using Iterator
        // Obtaining the Iterator
        Iterator<String> itr = setOfStocks.iterator();

        // traversing over HashSet
        System.out.println("Traversing over Set using Iterator");
        while (itr.hasNext()) {
            System.out.println(itr.next());
        }

        // Example 2 - looping over HashSet using for loop
        System.out.println("Looping over HashSet using advanced for loop");
        for (String stock : setOfStocks) {
            System.out.println(stock);
        }
    }
}
