package stringCoding;

public class RemoveAllWhiteSpcaesFromString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "my name is khan, king khan";

		System.out.println(str.replaceAll(" ", ""));
	}

}
