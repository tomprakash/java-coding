package Array;

public class Count_Pairs_In_An_Array {

	public static int countPairsInArray(int arr[]) {

		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (i * arr[i] > j * arr[j])
					count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {

		int arr[] = { 1, 5, 7, 9, -13 };
		System.out.println(countPairsInArray(arr));
	}
}
