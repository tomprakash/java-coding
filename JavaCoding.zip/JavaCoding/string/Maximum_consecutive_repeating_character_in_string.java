package string;

public class Maximum_consecutive_repeating_character_in_string {

	public static void main(String[] args) {

		Maximum_consecutive_repeating_character("aacbbddaaabbbbccccc");

	}

	public static void Maximum_consecutive_repeating_character(String str) {

		int maxCount = 0;
		char res = str.charAt(0);
		int currCount = 1;

		for (int i = 1; i < str.length(); i++) {
			if (i < str.length() - 1 && str.charAt(i) == str.charAt(i + 1))
				currCount++;
			else {
				if (currCount > maxCount) {

					maxCount = currCount;
					res = str.charAt(i);
				}
				// else - this else is optional anyhow it will come in 28th line
				// if condition is false.
				currCount = 1;
			}
		}

		System.out.println(res + " : " + maxCount);
	}
}
