package stringCoding;

public class Maximum_Consecutive_Zeroes_in_Concatenated_Binary_String {

	public void maximumFindConsecutiveZeros(String str) {

	}

}
