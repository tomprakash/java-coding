package string;

public class Rearrange_characters_in_a_string_such_that_no_two_adjacent_are_same {

	public static void main(String[] args) {

	}

}
