package Array;

import java.util.HashMap;
import java.util.Set;

public class find_the_duplicate_number_on_a_given_integer_array {

	public static void find_the_duplicate(int arr[]) {
		HashMap<Integer, Integer> baseMap = new HashMap<Integer, Integer>();

		for (Integer a : arr) {
			if (baseMap.containsKey(a)) {
				baseMap.put(a, baseMap.get(a) + 1);
			} else {
				baseMap.put(a, 1);
			}
		}

		System.out.println(baseMap);
		Set<Integer> keys = baseMap.keySet();
		for (Integer i : keys) {
			if (baseMap.get(i) > 1) {
				System.out.println(i + "  is " + baseMap.get(i) + " times");
			}
		}
	}

	public static void main(String args[]) {

		int a[] = { 1, 1, 2, 3, 4, 2, 3, 4, 5, 9, 8 };
		find_the_duplicate(a);
	}
}
