package Amazon_SDET;

public class Search_an_element_in_an_array_where_difference_between_adjacent_elements_is_1 {

	public static int Search_an_element(int arr[], int x) {
		// Travers the given array starting
		// from leftmost element
		int n = arr.length;
		int i = 0;
		while (i < n) {

			// If x is found at index i
			if (arr[i] == x)
				return i;

			else {
				// Jump the difference between current array element and x
				i = i + Math.abs(arr[i] - x);
				System.out.println("i " + i);
				System.out.println("arr[i] " + arr[i]);
			}
		}

		System.out.println("number is not present!");

		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 8, 7, 6, 7, 6, 5, 4, 3, 2, 3, 4, 3 };
		int num = 3;
		System.out.println(Search_an_element(arr, num));
	}

}
