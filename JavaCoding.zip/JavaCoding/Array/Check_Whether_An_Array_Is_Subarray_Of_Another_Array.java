package Array;

import java.util.HashSet;
import java.util.Set;

public class Check_Whether_An_Array_Is_Subarray_Of_Another_Array {

	public static boolean Check_Whether_An_Array_Is_Subarray_Of_Another_Array(int[] arr1, int[] arr2) {

		// Create an empty Set
		Set<Integer> set = new HashSet<>();

		// Iterate through the array
		for (int t : arr1) {
			// Add each element into the set
			set.add(t);
		}
		for (int t : arr2) {
			// Add each element into the set
			if (!set.contains(t))
				return false;
		}
		return true;

	}

	public static void main(String args[]) {
		int arr1[] = { 1, 2, 3, 4 };
		int arr2[] = { 1, 5 };

		System.out.println(Check_Whether_An_Array_Is_Subarray_Of_Another_Array(arr1, arr2));

	}
}
