package stringCoding;

public class ReverseAString {

	public static void main(String[] args)

	{
		String str = "Tomprakash is my   name";

		StringBuffer reverse = new StringBuffer();

		char[] chars = str.toCharArray();

		for (int i = chars.length - 1; i >= 0; i--) {
			reverse.append(chars[i]);
		}

		System.out.println(reverse);
	}

}
