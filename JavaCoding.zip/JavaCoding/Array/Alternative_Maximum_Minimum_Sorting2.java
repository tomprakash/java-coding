package Array;
//https://codereview.stackexchange.com/questions/112840/reordering-an-array-even-elements-descending-odd-elements-ascending

public class Alternative_Maximum_Minimum_Sorting2 {

	public static void main(String[] args) {
		int[] array = { 2, 1, 4, 6, 5, 3, 7 };

		rearrange(array);

		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}

	private static void rearrange(int[] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if ((i % 2 == 0 && array[i] < array[j]) || (i % 2 != 0 && array[i] > array[j])) {
					swap(array, i, j);
				}
			}
		}
	}

	private static void swap(int[] array, int i, int j) {
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}

}