package stringCoding;

import java.util.Arrays;

public class AnagramString {

	public static void main(String[] args) {

		String str1 = "ram";
		String str2 = "mar";

		char[] str1arr = str1.toCharArray();
		char[] str2arr = str2.toCharArray();

		if (Isanagram(str1arr, str2arr))
			System.out.println("anagram");
		else
			System.out.println("Not anagram");

	}

	public static boolean Isanagram(char[] str1arr, char[] str2arr) {

		if (str1arr.length != str2arr.length)
			return false;

		Arrays.sort(str1arr);
		Arrays.sort(str2arr);

		if (!Arrays.equals(str1arr, str2arr))
			return false;
		return true;

	}
}