package string;

public class Find_the_first_repeated_word_in_a_string {

	public static void main(String[] args) {

		String str = "You cannot end any sentence with because because because is a conjunction";

		String arr[] = str.split(" ");

		boolean found = false;
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i].equals(arr[j])) {
					found = true;
				}
			}

			if (found) {
				System.out.println("the first repeated element is : " + arr[i]);
				break;
			}

		}
	}
}
