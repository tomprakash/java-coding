package arrayCoding;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class Sample {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		FileInputStream fis = new FileInputStream("D:\\rk.properties");
		Properties prop = new Properties();
		prop.load(fis);
		System.out.println(prop.getProperty("url"));
	}

}
