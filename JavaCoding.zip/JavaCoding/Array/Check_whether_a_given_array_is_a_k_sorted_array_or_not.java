package Array;

import java.util.Arrays;

public class Check_whether_a_given_array_is_a_k_sorted_array_or_not {

	public static void main(String[] args) {

		int arr[] = { 3, 2, 1, 5, 6, 4 };

		int k = 2;

		if (isKSortedArray(arr, k))
			System.out.println("Yes");
		else
			System.out.println("No");
	}

	public static boolean isKSortedArray(int arr[], int k) {
		int copy[] = new int[arr.length];

		for (int i = 0; i < arr.length; i++) {

			copy[i] = arr[i];
		}

		Arrays.sort(copy);

		for (int i = 0; i < arr.length; i++) {
			int j = Arrays.binarySearch(copy, arr[i]);
			if (Math.abs(i - j) > k)
				return false;
		}
		return true;
	}

}