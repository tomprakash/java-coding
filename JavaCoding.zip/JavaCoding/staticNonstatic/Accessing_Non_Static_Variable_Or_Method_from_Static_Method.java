package staticNonstatic;

public class Accessing_Non_Static_Variable_Or_Method_from_Static_Method {

		  private static int aStaticVariable = 1;
		  private int aNonStaticVariable = 2;

		  private static void aStaticMethod() {
		    System.out.println(aNonStaticVariable);
		    aNonStaticMethod();
		  }

		  private void aNonStaticMethod() {
		    System.out.println(aStaticVariable);
		  }

		}


//https://javarevisited.blogspot.com/2017/10/can-non-static-method-access-static.html#ixzz5ojQ1pzAf



