package Amazon_SDET;

public class Biggest_Palindromic_Number_In_An_Array {

	public static void main(String[] args) {

		int arr[] = { 121, 151, 181, 212, 919 };

		System.out.println(IsLargestPalindrome(arr));

	}

	public static boolean IsPalindrome(int k) {

		int num = k;// this step is important otherwise at end if u compare k
					// with rev ,
		// k will be zero and function will return false sdo we have to store it
		// in some other variable
		int r = 0;
		int rev = 0;
		while (k != 0) {

			r = k % 10;

			rev = rev * 10 + r;

			k = k / 10;
		}
		if (num == rev)
			return true;
		return false;
	}

	public static int IsLargestPalindrome(int arr[]) {
		int largest = Integer.MIN_VALUE;
		for (int i = 0; i < arr.length; i++) {

			if (IsPalindrome(arr[i]) && arr[i] > largest) {
				largest = arr[i];
			}
		}
		return largest;
	}

}
