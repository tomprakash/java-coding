package Array;
//https://www.geeksforgeeks.org/find-sum-of-factorials-in-an-array/

public class Find_sum_of_factorials_in_an_array {

	public static void main(String[] args) {

		int arr[] = { 7, 3, 5, 4, 8 };

		findSUmOfFactorial(arr);
	}

	public static void findSUmOfFactorial(int arr[]) {

		int sum = 0;
		for (int i = 0; i < arr.length; i++) {

			sum = sum + factorial(arr[i]);
		}
		System.out.println("sum " + sum);
	}

	public static int factorial(int n) {

		if (n == 1)
			return 1;
		else
			return n * factorial(n - 1);

	}
}
