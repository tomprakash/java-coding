package Numbers;

public class NumberAddition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=01;
		int b=a+1;
		
		System.out.println(b);
	}

}
