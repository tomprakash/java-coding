package Random;

public class Forloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = -1;
		for (n = -1; n <= 5; n++) {
			n = n + 1;
		}
		System.out.println(n);

	}

}
