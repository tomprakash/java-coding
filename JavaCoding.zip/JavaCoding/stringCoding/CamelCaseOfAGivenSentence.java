package stringCoding;

public class CamelCaseOfAGivenSentence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "I get intern at geeksforgeeks";
		convert(str);
	}

	static void convert(String s) {
		char arr[] = s.toCharArray();
		int n = s.length();
		for (int i = 0; i < n; i++) {

			if (arr[i] == ' ') {

				if (i != 0)
					arr[i] = (char) (arr[i + 1] - 32);

				System.out.print(arr[i]);
				i++;
			} else
				System.out.print(arr[i]);
		}

	}
}
