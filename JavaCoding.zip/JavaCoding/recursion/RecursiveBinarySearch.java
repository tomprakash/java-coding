package recursion;

public class RecursiveBinarySearch {

	public static void main(String[] args) {

		int arr[] = { 3, 4, 5, 6, 7, 8 };
		int r = arr.length - 1;
		int x = 8;
		int result = recursiveBinarySearch(arr, 0, r, x);
		if (result == -1)
			System.out.println("Element not present");
		else
			System.out.println("Element found at index " + result);
	}

	public static int recursiveBinarySearch(int arr[], int l, int r, int x) {
		// if (r >= l) {
		while (l <= r) {
			int mid = l + (r - l) / 2;
			if (arr[mid] == x)
				return mid;
			if (arr[mid] > x)
				return recursiveBinarySearch(arr, l, mid - 1, x);
			return recursiveBinarySearch(arr, mid + 1, r, x);
		}
		return -1;
	}
}
