package Array;
//https://www.geeksforgeeks.org/sort-first-half-in-ascending-and-second-half-in-descending-order/

import java.util.Arrays;

public class Sort_first_half_in_ascending_and_second_half_in_descending_order {

	public static void main(String[] args) {

		int arr[] = { 1, 3, 2, 5, 4, 7, 10 };
		int n = arr.length;
		Arrays.sort(arr);
		halfAscendingHalfDescending(arr, n);
	}

	public static void halfAscendingHalfDescending(int arr[], int n) {

		int half = arr.length / 2;
		for (int i = 0; i < half; i++) {
			System.out.print(arr[i] + " ");
		}

		for (int i = arr.length - 1; i >= half; i--) {
			System.out.print(arr[i] + " ");
		}

	}
}
