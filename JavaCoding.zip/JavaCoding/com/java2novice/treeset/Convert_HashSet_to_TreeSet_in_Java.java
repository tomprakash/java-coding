package com.java2novice.treeset;

import java.util.HashSet; 
import java.util.Set; 
import java.util.TreeSet; 
  
public class Convert_HashSet_to_TreeSet_in_Java { 
  
    public static void main(String[] args) 
    { 
  
        // Get the HashSet 
        Set<String> setobj = new HashSet<>(); 
        setobj.add("Welcome"); 
        setobj.add("To"); 
        setobj.add("Geeks"); 
        setobj.add("For"); 
        setobj.add("Geeks"); 
  
        System.out.println("HashSet: "+ setobj); 
  
        // Convert the HashSet to TreeSet 
        Set<String> hashSetToTreeSet 
            = new TreeSet<>(setobj); 
  
        // Print the TreeSet 
        System.out.println("TreeSet: "
                           + hashSetToTreeSet); 
    } 
} 
