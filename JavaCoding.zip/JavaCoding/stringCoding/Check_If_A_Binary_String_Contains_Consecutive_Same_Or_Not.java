package stringCoding;

public class Check_If_A_Binary_String_Contains_Consecutive_Same_Or_Not {

	public static boolean consecutive_Same_Or_Not(String str) {

		for (int i = 1; i < str.length(); i++) {
			if (str.charAt(i) == str.charAt(i - 1))
				return false;
		}

		// If the string is alternating
		return true;
	}

	public static void main(String args[]) {
		System.out.println(consecutive_Same_Or_Not("010101"));
	}
}
