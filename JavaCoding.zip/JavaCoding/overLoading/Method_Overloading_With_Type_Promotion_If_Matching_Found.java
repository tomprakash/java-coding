package overLoading;

public class Method_Overloading_With_Type_Promotion_If_Matching_Found {

	void sum(int a, int b) {
		System.out.println("int arg method invoked");
	}

	void sum(long a, long b) {
		System.out.println("long arg method invoked");
	}

	public static void main(String args[]) {
		Method_Overloading_With_Type_Promotion_If_Matching_Found obj = new Method_Overloading_With_Type_Promotion_If_Matching_Found();
		obj.sum(20, 20);// now int arg sum() method gets invoked
	}
}
