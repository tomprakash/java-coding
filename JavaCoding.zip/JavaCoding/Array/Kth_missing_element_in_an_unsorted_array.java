package Array;
//

import java.util.SortedSet;
import java.util.TreeSet;

public class Kth_missing_element_in_an_unsorted_array {

	public static void main(String[] args) {
		int arr[] = { 12, 4, 5, 6, 8, 9, -2, -1 };
	
		SortedSet<Integer> set = new TreeSet<>();

		for (int i = 0; i < arr.length; i++) {
			set.add(arr[i]);
		}
		int k = 1;
		int count = 0;
		int n = 4;
		System.out.println();
		for (int j = set.first(); j < set.last(); j++) {
			if (!set.contains(set.first() + k)){
				count++;
				System.out.println("count :"+count +"k :"+k);
			}
			if (count == n)
				System.out.println("Missing element is " + set.first() + k);
		}
	}

}
