package Numbers;

public class PrimeNumber {

	public static void main(String[] args) {
		int p = 41;
		int count = 0;
		int k=p/2;
		System.out.println("k "+k);
		for (int i = 2; i < p / 2; i++) {
			if (p % i == 0){
				System.out.println("i "+i);
				count++;
			}
		}
		if (count == 1)
			System.out.println("Number is not prime");
		else
			System.out.println("Number is prime");
	}

}
