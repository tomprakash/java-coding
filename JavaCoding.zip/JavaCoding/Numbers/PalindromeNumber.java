package Numbers;

public class PalindromeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 454;
		int r, sum = 0;
		while (i > 0) {
			r = i % 10;
			sum = (sum * 10) + r;
			i = i / 10;
		}
		System.out.println(sum);
	}

}
