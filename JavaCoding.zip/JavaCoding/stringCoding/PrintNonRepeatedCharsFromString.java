package stringCoding;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class PrintNonRepeatedCharsFromString {

	public static StringBuffer NonrepeeatedChars(String str)

	{
		StringBuffer sb = new StringBuffer();
		HashMap<Character, Integer> hm = new HashMap<Character, Integer>();
		char[] chrs = str.toCharArray();
		for (Character ch : chrs)

		{
			if (hm.containsKey(ch)) {
				hm.put(ch, hm.get(ch) + 1);
			} else
				hm.put(ch, 1);

		}

		Set<Character> keys = hm.keySet();
		for (Character ch : keys) {
			if (hm.get(ch) == 1) {
				sb.append(ch);
			}
		}

		System.out.println(sb);
		return sb;

	}

	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("ENter the String with duplicates");
		String str = sc.next();
		PrintNonRepeatedCharsFromString rd = new PrintNonRepeatedCharsFromString();
		System.out.println("String without duplicates :" + NonrepeeatedChars(str));
	}
}

// same way it can be done for those which are repeated..might be twice or
// thrice..whatever by giving conditions in for loop.