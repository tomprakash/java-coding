package arrayCoding;

import java.util.Arrays;

public class FindMissingNumberInArray {

	public static void main(String[] args) {

		int[] array = { 1, 2, 3, 4, 5, 7, 8 };
		int n = array.length + 1;
		int missingnumber = FindMissingNumber(array, n);

		System.out.println("the missing number" + missingnumber);
	}

	public static int FindMissingNumber(int[] array, int n)

	{
		int actualsum = 0;
		int expectedsum = (n * (n + 1) / 2);
		for (int i : array)

		{
			actualsum = actualsum + i;
		}
		return expectedsum - actualsum;

	}

}
