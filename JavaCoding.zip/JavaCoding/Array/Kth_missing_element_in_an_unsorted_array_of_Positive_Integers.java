package Array;

//this works only for positive integer
import java.util.Arrays;

public class Kth_missing_element_in_an_unsorted_array_of_Positive_Integers {

	public static void main(String[] args) {
		// int arr[] = { 2, 4, 6, 8, 9, 12 };

		int arr[] = { 12, 4, 5, 6, 8, 9 };
		Arrays.sort(arr);
		int count = 0;
		int n = 2;
		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i + 1] - arr[i] != 1)
				count++;
			if (count == n) {
				System.out.println(arr[i] + 1);
				break;
			}
		}
		System.out.println(count);
	}
}
