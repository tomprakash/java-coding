package Array;

import java.util.Arrays;

public class Is_One_Array_Rotation_Of_Another {
/*
 This program will not work as output is again in array format, 
 see Is_One_Array_Rotation_Of_Another2
 * */
	public static boolean One_Array_Rotation_Of_Another(int arr1[], int arr2[]) {

		int temp[] = new int[arr1.length + arr2.length];
		int index = 0;
		for (int i = 0; i < arr1.length; i++) {
			temp[index] = arr1[i];
			index++;
		}
		System.out.println(index);
		for (int i = 0; i < arr2.length; i++) {
			temp[index] = arr2[i];
			index++;
		}

		for (int i = 0; i < temp.length; i++) {
			System.out.println(temp[i]);
		}

		String actual = Arrays.toString(temp);
		System.out.println(actual);
	
		String rotated = Arrays.toString(arr1);
		System.out.println(rotated);
		Arrays.toString(arr2);
		if (actual.indexOf(rotated) == -1)
			return false;
		return true;
	}

	public static void main(String[] args) {

		int arr1[] = { 1, 2, 3, 4, 5 };
		int arr2[] = { 2, 3, 4, 5, 1 };
		System.out.println(One_Array_Rotation_Of_Another(arr1, arr2));
	}
}
