package Array;

public class Leaders_In_An_Array {

	public static void find_Leaders_In_An_Array(int arr[]) {

		for (int i = 0; i < arr.length; i++) {
			int j;
			for (j = i + 1; j < arr.length; j++) {

				if ((arr[i] <= arr[j])) {
					break;
				}
			}
			if (j == arr.length)
				System.out.println(arr[i]);

		}
	}

	public static void main(String[] args) {

		int arr[] = { 16, 2, 3, 9, 0, 1, 8 };
		find_Leaders_In_An_Array(arr);
	}
}
