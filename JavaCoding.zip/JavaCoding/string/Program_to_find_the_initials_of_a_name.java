package string;

public class Program_to_find_the_initials_of_a_name {

	public static void main(String[] args) {

		String name = "tom prakash singh";
		 System.out.print(Character.toUpperCase(name.charAt(0))); 
		for(int i=1;i<name.length();i++){
			
			if(name.charAt(i)==' ')
				 System.out.print(" " + Character.toUpperCase(name.charAt(i+1))); 
		}
	}

}
