package string;

import java.util.HashSet;
import java.util.Set;

public class First_Repeating_Char_In_String {

	public static void main(String[] args) {
		First_Repeating_Char("acbsfcgsbva");
	}

	public static void First_Repeating_Char(String str) {

		char[] arr = str.toCharArray();
		Set<Character> set = new HashSet<Character>();
		for (int i = 0; i < arr.length; i++) {

			if (set.contains(arr[i])){
				System.out.println("first repeating char is :" + arr[i]);
			break;
			}
			else
				set.add(arr[i]);
		}
	}
}
