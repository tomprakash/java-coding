package arrayCoding;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class RemoveDuplicatesInArray {

	public static void main(String[] args) {
		int arr[] = { 1, 2, 2, 3, 3, 4, 4, 5, 6, 7 };
		int n = arr.length;
		removeduplicates(arr, n);
	}

	static void removeduplicates(int arr[], int n) {
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (int i = 0; i < arr.length; i++) {

			if (map.containsKey(arr[i]))
				map.put(arr[i], map.get(arr[i]) + 1);
			else
				map.put(arr[i], 1);
		}

		Set<Entry<Integer, Integer>> entryset = map.entrySet();

		for (Entry<Integer, Integer> entry : entryset) {

			System.out.println(entry.getKey());
		}

	}
}
