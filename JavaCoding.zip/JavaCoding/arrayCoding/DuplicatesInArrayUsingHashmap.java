package arrayCoding;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DuplicatesInArrayUsingHashmap {
	public static void main(String args[]) {
		String[] names = { "Java", "JavaScript", "Python", "C", "Ruby", "Java", "C", "Ruby" };

		Map<String, Integer> nameAndCount = new HashMap<>();

		for (String name : names) {
			if (nameAndCount.containsKey(name)) {
				nameAndCount.put(name, nameAndCount.get(name) + 1);
			} else
				nameAndCount.put(name, 1);
		}
		Set<Entry<String, Integer>> entrySet = nameAndCount.entrySet();
		for (Entry<String, Integer> entry : entrySet) {
			if (entry.getValue() > 1) {
				System.out.println("Duplicate element from array : " + entry.getKey());

			}

		}

	}

}
