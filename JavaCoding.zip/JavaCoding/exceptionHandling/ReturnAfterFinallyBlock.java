package exceptionHandling;

public class ReturnAfterFinallyBlock {
	// the major concept here is a method returns only single value at a time
	// not multiple values, so from any block if it is already returning a value
	// then
	// if return is there in try , it should be in catch also
	// if catch block is not present
	// uncomment catch block and see.
	public static int returnStatementAfterFinallyBlock() {

		try {
			// int result = 18 / 0;
			return 5;
		}
		/*
		 * catch (ArithmeticException e) { System.out.println(
		 * "Handled exception"); return 6; }
		 */

		finally {
			System.out.println("Finally block alwasys executes for source clean up");
			// return 10;
		}
		// return 10;
		// int b=10;
		// any statement after finally block gives "unreachable code" compile
		// time error.
	}

	public static void main(String[] args) {

		System.out.println(returnStatementAfterFinallyBlock());
	}
}
