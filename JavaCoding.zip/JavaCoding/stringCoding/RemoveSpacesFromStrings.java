package stringCoding;

import java.util.Scanner;

public class RemoveSpacesFromStrings {

	public static void main(String args[]) {
		String str, strWithoutSpace;
		int i;
		Scanner scan = new Scanner(System.in);

		System.out.print("Enter a Sentence : ");
		str = scan.nextLine();

		// 1. Using replaceAll() Method

		strWithoutSpace = str.replaceAll(" ", "");

		System.out.println(strWithoutSpace);
	}
}
