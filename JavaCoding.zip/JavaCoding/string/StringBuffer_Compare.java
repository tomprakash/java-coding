package string;

public class StringBuffer_Compare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer s = new StringBuffer("baa");
		
		StringBuffer s1 = new StringBuffer("aab");
		
		System.out.println(s.toString().equals(s1.toString()));

	}

}
