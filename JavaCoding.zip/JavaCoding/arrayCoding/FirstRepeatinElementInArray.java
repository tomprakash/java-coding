package arrayCoding;

public class FirstRepeatinElementInArray {

	public static void main(String args[]) {
		int array[] = { 1, 2, 3, 4, 5, 3 };
		int i;
		for (i = 0; i < array.length; i++) {
			for (int j = 1; i < array.length; i++)

			{
				if (array[i] == array[j])
					break;
			}

		}
		System.out.println("the first repeated element is" + array[i]);
	}

}
