package string;
//https://www.geeksforgeeks.org/check-if-all-the-1s-in-a-binary-string-are-equidistant-or-not/

public class Check_if_all_the_1s_in_a_binary_string_are_equidistant_or_not {

	public static void main(String[] args) {

		String str = "0111001";
		if (check_If_All_The_1s_Equidistant_Or_Not(str))
			System.out.println("Yes");
		else
			System.out.println("No");
	}

	public static boolean check_If_All_The_1s_Equidistant_Or_Not(String str) {

		int k = 0;

		for (int i = 0; i < str.length(); i++) {

			if (str.charAt(i) == '1') {
				k++;
			}
		}
		int[] index = new int[k];
		int j = 0;
		for (int i = 0; i < str.length(); i++) {

			if (str.charAt(i) == '1') {
				index[j] = i;
				j++;
			}
		}

		for (int i = 0; i < index.length - 1; i++) {

			System.out.println(index[i]);
		}
		System.out.println("index.length " + index.length);
		for (int i = 0; i < index.length - 1; i++) {
			System.out.println("difference " + (index[i + 1] - index[i]));
			if (Math.abs(index[i + 1] - index[i]) != 1) {
				return false;
			}
		}
		return true;

	}

}
