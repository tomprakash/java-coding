package string;

public class Count_strings_that_end_with_the_given_pattern {

	public static int Count_strings(String arr[]) {
		int count = 0;
		for (int i = 0; i < arr.length; i++) {

			if (arr[i].endsWith("ks"))
				count++;
		}
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String arr[] = { "geeks", "geeksforgeeks", "games", "unit" };

		System.out.println(Count_strings(arr));
	}

}
