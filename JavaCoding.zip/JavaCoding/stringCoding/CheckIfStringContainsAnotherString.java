package stringCoding;

import java.util.Scanner;
//logic of this program is not correct , it searches for all the charaters in the super 
//string and return true is found, not exactly the substring, yes sometimes it works.
//to break the code try first string:afgh and second string abcsafgah....it will return true which is wrong.

public class CheckIfStringContainsAnotherString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		System.out.print("Please enter first String: ");
		String string1 = input.next();
		System.out.print("Please enter a sub String: ");
		String string2 = input.next();
		if (isSubstring(string1, string2)) {
			System.out.println("The Second string is a substring of the second.");
		} else {
			System.out.println("The Second string is NOT a substring of the second.");
		}
	}

	public static boolean isSubstring(String string1, String string2) {

		boolean match = false;

		for (int i = 0; i < string1.length(); i++) {
			for (int j = 0; j < string2.length(); j++) {
				if (string1.length() - 1 == i) {
					return false;
				}
				System.out.println(string1.charAt(i) + " " + string2.charAt(j));
				if (string1.charAt(i) == string2.charAt(j)) {
					i++;
					if (string2.length() - 1 == j) {
						return true;
					}
					// System.out.println(string1.charAt(i)+"
					// "+string2.charAt(j));
				} else {
					i = 0;
					if (string2.length() - 1 == j) {
						return match;
					}
				}

			}

		}
		return match;

	}

}
