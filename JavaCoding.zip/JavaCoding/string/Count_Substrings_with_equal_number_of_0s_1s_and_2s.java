package string;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class Count_Substrings_with_equal_number_of_0s_1s_and_2s {

	public static int Count_Substrings_with_equal_number_of_0s_1s_2s(String str) {
		int count = 0;
		String temp;

		for (int i = 0; i < str.length(); i++) {

			for (int j = i + 1; j <= str.length(); j++) {

				temp = str.substring(i, j);

				if ((temp.length() >= 3) && (count_0s_1s_2s(temp))) {
					System.out.println("temp is " + temp);
					count++;
				}
			}
		}
		return count;
	}

	public static boolean count_0s_1s_2s(String str) {

		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		char[] arr = str.toCharArray();
		for (int i = 0; i < arr.length; i++) {
			if (!map.containsKey(arr[i]))
				map.put(arr[i], 1);
			else
				map.put(arr[i], map.get(arr[i]) + 1);
		}

		int max = Collections.max(map.values());

		for (Entry<Character, Integer> entry : map.entrySet()) {
			if (entry.getValue() != max)
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "0102010";

		System.out.println(Count_Substrings_with_equal_number_of_0s_1s_2s(str));
	}

}
