package stringCoding;

public class CountNumberOfWordsInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Tomprakash";
		char[] chars = str.toCharArray();
		int wordcount = chars.length;
		System.out.println("the number of words in the string are " + wordcount);
	}

}
