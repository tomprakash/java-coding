package string;
//This solution works when we just want to change the first letter of each word

public class convert_First_Character_Uppercase_In_A_Sentence_Easy_Way {

	public static void main(String[] args) {

		String str = "tom prakash singh sahu";
		System.out.println(toUpperCaseFirstLetterOnly(str));
	}

	static String toUpperCaseFirstLetterOnly(String str) {
		String[] words = str.split(" ");
		StringBuilder ret = new StringBuilder();
		for (int i = 0; i < words.length; i++) {
			ret.append(Character.toUpperCase(words[i].charAt(0)));
			ret.append(words[i].substring(1));
			if (i < words.length - 1) {
				ret.append(' ');
			}
		}
		return ret.toString();
	}

}
