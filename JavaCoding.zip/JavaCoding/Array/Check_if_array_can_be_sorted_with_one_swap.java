package Array;

public class Check_if_array_can_be_sorted_with_one_swap {

	public static String array_can_be_sorted_with_one_swap(int arr[]) {
		int temp;
		int copy[] = new int[arr.length];
		int count = 0;

		for (int i = 0; i < arr.length; i++) {

			copy[i] = arr[i];
		}
//sorting
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {

				if (arr[i] < arr[j]) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}

		for(int i = 0; i < arr.length; i++)
		{
			System.out.println(arr[i]);
		}
		for (int j = 0; j < arr.length; j++) {

			if (copy[j] != arr[j])
				count++;
		}
		if (count == 0 || count == 2) {
			return "YES";
		}
		return "NO";
	}

	public static void main(String[] args) {
		int arr[] = { 1, 2,6,3,5 };
		System.out.println(array_can_be_sorted_with_one_swap(arr));

	}

}
