package string_programming_and_coding_interview_questions;

import java.util.Arrays;

public class Check_if_two_string_are_anagrams {

	public static boolean anagramStrings(String str1, String str2) {

		if (str1.length() != str2.length())
			return false;

		char[] str1arr = str1.toCharArray();
		char[] str2arr = str2.toCharArray();

		Arrays.sort(str1arr);
		Arrays.sort(str2arr);

		String str11 = new String(str1arr);
		String str22 = new String(str2arr);

		if (str11.equals(str22))
			return true;

		return false;
	}

	public static void main(String[] args) {

		String str1 = "army";
		String str2 = "ymar";

		System.out.println(anagramStrings(str1, str2));
	}

}
