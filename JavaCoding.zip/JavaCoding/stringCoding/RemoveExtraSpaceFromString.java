package stringCoding;

public class RemoveExtraSpaceFromString {

	public static void main(String[] args) {
		String str = "  Tom   Prakash  @";
		String newstr = "";
		char arr[] = str.toCharArray();
		for (int i = 0; i < arr.length - 1; i++) {
			if (!(arr[i] == ' ' && arr[i + 1] == ' ')) {
				newstr = newstr + arr[i + 1];
			}
		}
		System.out.println(newstr);
	}

}
