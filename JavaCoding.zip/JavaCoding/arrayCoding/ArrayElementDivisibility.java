package arrayCoding;

import java.util.Arrays;

public class ArrayElementDivisibility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int array[] = { 2, 4, 6, 8, 10, 12 };
		Arrays.sort(array);
		int min = array[0];

		boolean smallest = divisibility(min, array);

		if (smallest)

		{
			System.out.println("the number which divides all the number is " + min);
		} else {

			System.out.println("there is no such number");
		}
	}

	public static boolean divisibility(int min, int arr[]) {
		boolean a = false;
		for (int i = 0; i < arr.length; i++)
			if (arr[i] % min != 0) {
				return true;
			} else {
				return false;
			}
		return false;
	}

}
