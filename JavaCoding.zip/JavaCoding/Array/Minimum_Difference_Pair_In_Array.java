package Array;

public class Minimum_Difference_Pair_In_Array {

	public static int findMinimumDifferencePairInArray(int arr[]) {

		int min = Integer.MAX_VALUE;
		int difference;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				difference = arr[i] - arr[j];
				if (Math.abs(difference) < min)
					min = difference;

			}
		}
		
return min;

	}
	
	public static void main(String[] args) {

		int arr[] = { 1,5,7,9,-13 };
		System.out.println(findMinimumDifferencePairInArray(arr));
	}
}
