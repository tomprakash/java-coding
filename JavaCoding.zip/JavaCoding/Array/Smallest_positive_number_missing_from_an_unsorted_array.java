package Array;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Smallest_positive_number_missing_from_an_unsorted_array {

	public static int find_the_smallest_positive_number_missing_from_an_unsorted_array(int arr[]){

		int number =0;
		Set<Integer> set = new HashSet<Integer>();
		for(int i=0;i<arr.length;i++){
			
			if(arr[i]>0){
				set.add(arr[i]);
			}
				
		}
		
		Iterator<Integer> itr = set.iterator();

		// traversing over HashSet
		System.out.println("Traversing over Set using Iterator");
		while(itr.hasNext()){
		 if(itr.next()!=++number)
			 return number;
		}
		return -1;
		
	}
	public static void main(String[] args) {

		int arr[] = { 1,2,3, 5, 7, 9, -13 };
		System.out.println(find_the_smallest_positive_number_missing_from_an_unsorted_array(arr));
	}
}
