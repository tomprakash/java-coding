package arrayCoding;

import java.util.HashSet;
import java.util.Set;

public class UnionAndIntersection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr1[] = { 1, 2, 1, 3, 4, 5, 2, 3, 2 };
		int arr2[] = { 4, 5, 2, 3, 2, 6, 7 };

		int i = 0, j = 0;

	}

}
