package string;

public class Check_if_a_string_contains_only_alphabets_using_ASCII_values {

	public static boolean if_a_string_contains_only_alphabets(String str) {
		for (int i = 0; i < str.length(); i++) {
			if (!(((int) str.charAt(i) >= 65 && (int) str.charAt(i) <= 90)
					|| ((int) str.charAt(i) >= 97 && (int) str.charAt(i) <= 122)))
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str1 = "Tomprakash";
		String str2 = "*&^&^%$";

		System.out.println(if_a_string_contains_only_alphabets(str1));
		System.out.println(if_a_string_contains_only_alphabets(str2));

	}

}
