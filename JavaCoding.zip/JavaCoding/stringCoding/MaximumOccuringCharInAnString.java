package stringCoding;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class MaximumOccuringCharInAnString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "aabbcacddbc";

		HashMap<Character, Integer> map = new HashMap<Character, Integer>();

		for (int i = 0; i < str.length(); i++) {
			if (map.containsKey(str.charAt(i)))
				map.put(str.charAt(i), map.get(str.charAt(i)) + 1);
			else
				map.put(str.charAt(i), 1);
		}

		int maxValueInMap = (Collections.max(map.values()));

		// This will return max value in the Hashmap
		for (Entry<Character, Integer> entry : map.entrySet()) {

			if (entry.getValue() == maxValueInMap) {
				System.out.println(entry.getKey() + " " + entry.getValue());
			}
		}
	}

}
