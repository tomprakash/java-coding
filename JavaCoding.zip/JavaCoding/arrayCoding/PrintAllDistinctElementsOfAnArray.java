package arrayCoding;

import java.util.HashSet;
import java.util.Set;

public class PrintAllDistinctElementsOfAnArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = { 1, 2, 1, 2, 2, 2, 3, 4, 5, 2, 3, 2, 2, 2, 2 };

		Set<Integer> set = new HashSet<Integer>();

		for (Integer a : arr) {

			if (set.contains(a) == false)
				set.add(a);

		}
		System.out.println("distinct elements are " + set);
	}

}
