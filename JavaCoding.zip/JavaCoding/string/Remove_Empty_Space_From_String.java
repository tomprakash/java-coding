package string;

public class Remove_Empty_Space_From_String {

	public static void removeEmptySpace(String sentence) {

		sentence = sentence.replaceAll(" ", "");
		System.out.println(sentence);
	}

	public static void main(String args[]) {

		removeEmptySpace("my name is");

	}
}
