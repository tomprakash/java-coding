package stringCoding;

public class PalindromeString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "aba";

		char[] chars = str.toCharArray();

		StringBuffer sb = new StringBuffer("");

		for (int i = chars.length - 1; i >= 0; i--)

		{
			sb.append(chars[i]);
		}
		System.out.println(sb);
		if (sb.toString().equals(str))
			System.out.println("palindrom");
		else
			System.out.println("Not palindrome");

	}

}
