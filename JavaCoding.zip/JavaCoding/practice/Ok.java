/*
public class FacebookSignUp {

	public static void main(String[] args) throws InterruptedException {
		
   // System.setProperty("webdriver.gecko.driver","D:\\selenium_software_dont_Move\\geckodriver-v0.20.0-win64\\geckodriver.exe");
	System.setProperty("webdriver.chrome.driver", "D:\\selenium_software_dont_Move\\chromedriver_win32\\chromedriver.exe");
	//DesiredCapabilities capabilities = DesiredCapabilities.firefox();
	//capabilities.setCapability("marionette", true);
	
	// Create a new instance of the Firefox driver
//	WebDriver fb = new FirefoxDriver();
	WebDriver fb= new ChromeDriver();
	fb.manage().window().maximize();
	
	//fb.get("https://www.facebook.com/");
	//fb.navigate().to("https://www.facebook.com/");
	
	fb.navigate().to("https://www.amazon.in/");
	Thread.sleep(7000);
			
			fb.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Tomprakash");
			fb.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Sahu");
			fb.findElement(By.xpath("//input[@name='reg_email__']")).sendKeys("7869084527");
			fb.findElement(By.xpath("//input[@name='reg_passwd__']")).sendKeys("Ninja@25");
					
			Select date = new Select(fb.findElement(By.xpath("id('day')")));
			
			date.selectByVisibleText("24");
			
			Select month = new Select(fb.findElement(By.xpath("id('month')")));
			
			month.selectByVisibleText("Dec");
			
			Select year = new Select(fb.findElement(By.xpath("id('year')")));
			
			year.selectByVisibleText("1989");
			
			//fb.findElement(By.className("_58mt")).click(); //use xpath here if it doesn't work.
			
			fb.findElement(By.xpath(".//*[@id='u_0_b']")).click();
			
			
			fb.findElement(By.xpath(".//button[@type='submit']")).click();
			
//	WebElement element = fb.findElement(By.xpath("//*[@id='searchDropdownBox']"));

	WebElement element1 = fb.findElement(By.xpath("//*[@id='nav-link-wishlist']/span[2]"));

	Actions builder = new Actions(fb);
	builder.moveToElement(element).build().perform();	
	Thread.sleep(3000);
	builder.moveToElement(element).build().perform();
    builder.clickAndHold().moveToElement(element1);					
    builder.moveToElement(element1).build().perform(); 
    builder.moveToElement(element1).perform();
    Thread.sleep(2000);
    String text=fb.findElement(By.xpath("//*[@id='nav-flyout-wishlist']/div[2]/a[4]")).getText();
    String innerHTML=fb.findElement(By.xpath("//*[@id='nav-flyout-wishlist']/div[2]/a[4]")).getAttribute("innerHTML");
    System.out.println("text is" + text);
    System.out.println("inner html is "+innerHTML);
   // String tooltip = element1.getText();
   // System.out.println(tooltip);
	Thread.sleep(3000);
  //  builder.moveToElement(element).build().perform(); 
	



*/