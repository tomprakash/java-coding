package arrayCoding;

public class DuplicatesInArray {

	public static void main(String args[]) {

		String[] names = { "Java", "JavaScript", "Python", "C", "Ruby", "Java", "C" };

		for (int i = 0; i < names.length; i++) {
			for (int j = i + 1; j < names.length; j++) {
				if (names[i].equals(names[j])) {

					System.out.println(names[j]);
				}
			}
		}

	}

}
