package stringCoding;

public class StringInAscendingOrder {

	public static void AscendingOrder(String str) {
		char[] ch = str.toCharArray();
		char temp;
		for (int i = 0; i < ch.length; i++) {

			for (int j = i + 1; j < ch.length; j++) {

				if ((int) ch[i] > (int) ch[j]) {

					temp = ch[i];
					ch[i] = ch[j];
					ch[j] = temp;
				}
			}
		}
		System.out.print("Ascending Order:");

		for (int i = 0; i < ch.length; i++)

		{

			System.out.print(ch[i] + ",");

		}
		// below is the code to convert char to string
		String newStr = new String(ch);
	//	System.out.println(newStr);

	}

	public static void main(String args[]) {

		AscendingOrder("tomprakash");

		//AscendingOrder("hgfe");
	}
}
