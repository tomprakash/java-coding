package string;

public class Move_spaces_to_front_of_string_in_single_traversal {

	public static String Move_spaces_to_front_of_string(String str) {

		char arr[] = str.toCharArray();
		String s1 = "";
		String s2 = "";
		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i] == ' ')
				s1 = s1 + " ";
			else
				s2 = s2 + arr[i];
		}
		return s1 + s2;

	}

	public static void main(String args[]) {

		System.out.println(Move_spaces_to_front_of_string("ok me hj"));
	}
}
