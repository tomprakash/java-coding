package Array;
//https://www.geeksforgeeks.org/count-elements-less-equal-given-value-sorted-rotated-array/
public class Count_elements_less_equal_given_value_sorted_rotated_array {

	public static void main(String[] args) {
		int arr[] = { -1, -4, 0, 2, 5, 8 };
		int n=0;
		
		for(int i=0;i<arr.length;i++){
			if(arr[i]==n)
				System.out.println(i+1);
		}
	}

}
