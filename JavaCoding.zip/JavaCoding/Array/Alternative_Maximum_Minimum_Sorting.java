package Array;
//https://www.geeksforgeeks.org/alternative-sorting/

import java.util.Arrays;

public class Alternative_Maximum_Minimum_Sorting {

	public static void main(String[] args) {

		int arr[] = { 7, 1, 2, 3, 4, 5, 6 };
		Arrays.sort(arr);
		int n = arr.length;
		alternative_Maximum_Minimum_Sorting(arr, n);
	}

	public static void alternative_Maximum_Minimum_Sorting(int arr[], int n) {

		int i = 0, j = n - 1;
		while (i < j) {
			System.out.print(arr[j--] + " ");
			System.out.print(arr[i++] + " ");
		}

		// If the total element in array is odd
		// then print the last middle element.
		if (n % 2 != 0)
			System.out.print(arr[i]);
	}
}
