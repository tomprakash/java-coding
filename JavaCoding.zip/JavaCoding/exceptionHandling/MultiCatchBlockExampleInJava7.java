package exceptionHandling;
// http://www.benchresources.net/multi-catch-block-in-java-1-7-version/
//read above for the rules.

public class MultiCatchBlockExampleInJava7 {

	public static void main(String[] args) {
		 
        try {
 
            // code which might raise exception
 
            // arithmetic operation
            int result = 18/0;
            System.out.println("Result of division : "
                    + result);
 
            // String operation
            String str = null;
            System.out.println("Lenght of the String : "
                    + str.length());
 
            // Number conversion
            String s1 = "abc";
            int convertedInt = Integer.parseInt(s1);
            System.out.println("Converted integer : "
                    + convertedInt);
 
            // Array operation
            char[] ch = new char[4];
            ch[7] = 'B';
        }
        catch(ArithmeticException | 
                NullPointerException |
                NumberFormatException | 
                ArrayIndexOutOfBoundsException ex) {
            // handling code 
            // for any type of exception from try block
            ex.printStackTrace();
        }
    }

}


