package Array;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Convert_Array_To_Set_In_Java {

	public static Set<Integer> convertArrayToSet(Integer[] array) 
    { 
  
        // Create an empty Set 
        Set<Integer> set = new HashSet<>(); 
  
        // Iterate through the array 
        for (int t : array) { 
            // Add each element into the set 
            set.add(t); 
        } 
  
        // Return the converted Set 
        return set; 
    } 
  
    public static void main(String args[]) 
    { 
        // Create an Array 
        Integer array[] = { 1,2,3,4 }; 
  
        // Print the Array 
        System.out.println("Array: " + Arrays.toString(array)); 
  
        // convert the Array to Set 
        Set<Integer> set = convertArrayToSet(array); 
  
        // Print the Set 
        System.out.println("Set: " + set); 
    } 
	
}
