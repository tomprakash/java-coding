package exceptionHandling;

public class ReturnStatementInTryCatchFinally {

	public static int returnValueFromMethodWhenCaughtException() {

		try {
			int result = 18 / 0;
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return 5;
		} finally {
			return 10;
		}
	}

	public static int returnValueFromMethodWhenNoException() {

		try {
			int result = 18 / 1;
			return result;
		} catch (Exception e) {
			return 5;
		} finally {
			return 10;
		}
	}

	public static int returnValueFromMethodWithoutCatchBlock() {

		try {
			int result = 18 / 2;
			return result;
		} finally {
			return 10;
		}
	}

	public static void main(String[] args) {
		System.out.println(returnValueFromMethodWhenCaughtException());
		System.out.println(returnValueFromMethodWhenNoException());
		System.out.println(returnValueFromMethodWithoutCatchBlock());
	}
}
