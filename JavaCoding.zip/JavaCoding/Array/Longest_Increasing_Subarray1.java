package Array;

public class Longest_Increasing_Subarray1 {

	public static void main(String[] args) {

		int arr[] = { 1,0 };
		System.out.println(find_Longest_Increasing_Subarray(arr));
	}

	public static int find_Longest_Increasing_Subarray(int arr[]) {

		int max = 1;
		int len = 1;

		for (int i = 1; i < arr.length; i++) {
			if (arr[i] > arr[i - 1])
				len++;

			else

			{
				if (max < len)
					max = len;
				len = 1;
			}
		}
/*		System.out.println("outside for loop");
		if (max < len)
			max = len;*/
		return max;
	}
}
