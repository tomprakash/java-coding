package exceptionHandling;

public class SystemExitInTryCatch {

	public static int returnStatementAfterFinallyBlock() {

		try {
		//	System.exit(5);
			int result = 18 / 0;
			
		}

		catch (ArithmeticException e) {
			System.out.println("Handled exception");
			System.exit(5);
		}

		finally {
			System.out.println("OK");
		}
		return 0;
	}

	public static void main(String[] args) {

		System.out.println(returnStatementAfterFinallyBlock());
	}

}
