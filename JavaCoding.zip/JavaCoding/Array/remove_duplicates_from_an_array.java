package Array;

import java.util.HashSet;
import java.util.Set;

public class remove_duplicates_from_an_array {

	public static int[] remove_duplicates(int arr[]) {

		Set<Integer> set = new HashSet<Integer>();
		for (int i = 0; i < arr.length; i++) {
			set.add(arr[i]);
		}

		int[] result = new int[set.size()];
		int i = 0;
		for (Integer u : set) {
			result[i++] = u;
		}
		for (int k = 0; k < result.length; k++) {
			System.out.println(result[k] + ",");
		}
		return result;

	}

	public static void main(String args[]) {

		int arr[] = { 2, 4, 3, 5, 7, 8, 9, 1, 2, 3, 4, 5, 6 };

		remove_duplicates(arr);
	}
}
