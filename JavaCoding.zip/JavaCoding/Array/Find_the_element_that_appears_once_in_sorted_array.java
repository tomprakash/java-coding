package Array;

import java.util.HashMap;
import java.util.Set;

public class Find_the_element_that_appears_once_in_sorted_array {

	public static void Find_element_that_appears_once_in_sorted_array(int arr[]) {

		HashMap<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < arr.length; i++) {
			if (map.containsKey(arr[i]))
				map.put(arr[i], map.get(arr[i]) + 1);
			else
				map.put(arr[i], 1);
		}

		Set<Integer> set = map.keySet();

		for (Integer s : set) {
			if (map.get(s) == 1)
				System.out.println(s);
		}

	}

	public static void main(String args[]) {

		int arr[] = { 2, 4, 3, 5, 7, 8, 9, 1, 2, 3, 4, 5, 6 };

		Find_element_that_appears_once_in_sorted_array(arr);
	}
}
