package overLoadingOverRiding;

public class Override_a_private_or_static_method_in_Java_Child_Class
		extends Override_a_private_or_static_method_in_Java_Parent_Class {

	public static void main(String[] args) {
		Override_a_private_or_static_method_in_Java_Parent_Class obj = new Override_a_private_or_static_method_in_Java_Child_Class();
		Override_a_private_or_static_method_in_Java_Parent_Class obj1 = new Override_a_private_or_static_method_in_Java_Parent_Class();
		Override_a_private_or_static_method_in_Java_Child_Class obj3 = (Override_a_private_or_static_method_in_Java_Child_Class) new Override_a_private_or_static_method_in_Java_Parent_Class();
		// obj.privatemethod(5, "tom");
		// obj1.privatemethod(5, "tom");
		obj3.privatemethod(5, "tom");// this gives ClassCasteException

	}

	private void privatemethod(int a, String b) {
		System.out.println("This is a private method in child class");
	}

	public static void staticMethod(int a, int b) {
		System.out.println("This is a static method in child class");
	}
}
