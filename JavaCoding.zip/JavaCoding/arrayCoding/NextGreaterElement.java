package arrayCoding;

public class NextGreaterElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int array[] = { 12, 45, 83, 23, 93, 47, 94, 15 };
		int b = 93;
		int index = 0;

		for (int j = 0; j < array.length; j++) {
			if (array[j] == b)
				index = j;
		}
		System.out.println(index);

		for (int i = index + 1; i < array.length; i++) {
			if (array[i] > b)
				System.out.println("Next greater element of " + b + " is : " + array[i]);
		}

	}

}
