package Array;

public class Next_Greater_Element {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5 };

		for (int i = 0; i < arr.length; i++) {

			for (int j = i + 1; j < arr.length; j++) {

				if (arr[j] > arr[i]) {
					System.out.println(arr[i] + "'s next greater element is " + arr[j]);
					break;
				}
			}
			if(i==arr.length-1)
				System.out.println(arr[i] + "'s next greater element is " + -1);	
		}
	}

}
