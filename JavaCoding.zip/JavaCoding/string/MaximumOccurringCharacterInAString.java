package string;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class MaximumOccurringCharacterInAString {

	public static void MaximumOccurringCharsInAString(String str) {

		HashMap<Character, Integer> map = new HashMap<Character, Integer>();

		char[] arr = str.toCharArray();
		for (int i = 0; i < arr.length - 1; i++) {
			if (map.containsKey(arr[i]))
				map.put(arr[i], map.get(arr[i]) + 1);
			else
				map.put(arr[i], 1);

		}
		int maxValueInMap = Collections.max(map.values());
		for (Entry<Character, Integer> entry : map.entrySet()) {
			if (entry.getValue() == maxValueInMap)
				System.out.println(entry.getKey()); // Print the key with max
													// value

		}
	}

	public static void main(String args[]) {
		MaximumOccurringCharsInAString("tomprakash");
	}

}
