package stringCoding;

public class CountVowelsAndConsonants {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Tomprakash singh";
		int vowels = 0;
		int conso = 0;
		int space = 0;
		char[] chars = str.toCharArray();

		for (int i = 0; i < chars.length; i++) {
			if (chars[i] == 'a' || chars[i] == 'e' || chars[i] == 'i' || chars[i] == 'o' || chars[i] == 'u')
				vowels++;
			else if (chars[i] == ' ')
				space++;
			else
				conso++;

		}

		System.out.println("vowels " + vowels + " consonants " + conso + " Space " + space);
	}

}
