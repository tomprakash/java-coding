package string;

import java.util.HashMap;
import java.util.Set;

public class Count_number_of_substrings_with_exactly_k_distinct_characters {

	public static int Count_number_of_substrings(String str, int k) {

		int count = 0;
		String temp;
		for (int i = 0; i < str.length(); i++) {

			for (int j = i + 1; j <= str.length(); j++) {

				temp = str.substring(i, j);

				if ((temp.length() >= 2) && (k_distinct_characters(temp, k))) {
					System.out.println("temp is " + temp);
					count++;
				}
			}
		}
		return count;

	}

	public static boolean k_distinct_characters(String str, int k) {

		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		char[] arr = str.toCharArray();
		for (int i = 0; i < arr.length; i++) {
			if (!map.containsKey(arr[i]))
				map.put(arr[i], 1);
			else
				map.put(arr[i], map.get(arr[i]) + 1);
		}

		Set<Character> keySet = map.keySet();
	//	System.out.println(keySet);
		int size = keySet.size();
		if (size == k) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {

		String str = "abc";
		int k = 3;
		System.out.println(Count_number_of_substrings(str, k));

	}

}
