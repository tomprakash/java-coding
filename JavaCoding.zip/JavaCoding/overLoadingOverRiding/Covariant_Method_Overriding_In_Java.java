package overLoadingOverRiding;

public class Covariant_Method_Overriding_In_Java {

}

class Alpha {
    Alpha doStuff(char c) {
        return new Alpha();
    }
}

class Beta extends Alpha {
    Beta doStuff(char c) { // legal override in Java 1.5
        return new Beta();
    }
}
