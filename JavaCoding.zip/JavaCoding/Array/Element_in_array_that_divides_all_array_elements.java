package Array;

public class Element_in_array_that_divides_all_array_elements {

	public static void main(String[] args) {

		int arr[] = { 4, 6, 8, 2, 10 };
		int n = arr.length;
		int ele = arr[0];
		for (int i = 0; i < arr.length; i++) {
			int count = 0;
			for (int j = 0; j < arr.length; j++) {
				if (i == 3 && (arr[j] % arr[i] == 0)) {
					System.out.println(arr[j] % arr[i]);
					count++;
					ele = arr[i];
				}

			}
			if (count == n) {
				System.out.println(ele);
				break;
			}

		}
	}

}
