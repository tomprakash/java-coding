package SnapDeal_SDET;

import java.util.HashSet;
import java.util.Set;

//Given an array:{ 2, 3, -7, 6, 8, 1, -10, 17 }, Find the smallest positive number missing.
public class SnapDeal4 {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, -7, 6, 8, 1, -10, 17 };

		Set<Integer> set = new HashSet<Integer>();

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > 0)
				set.add(arr[i]);
		}

		int missing = 1;
		for (int i = 0; i < set.size(); i++) {
			if (!set.contains(missing)) {
				System.out.println(missing);
				break;
			} else
				missing++;
		}
	}

}
