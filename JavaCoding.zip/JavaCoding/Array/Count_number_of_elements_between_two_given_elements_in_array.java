package Array;
//https://www.geeksforgeeks.org/count-number-elements-two-given-elements-array/

public class Count_number_of_elements_between_two_given_elements_in_array {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 6, 4, 7, 8, 9, 2, 5, 6, 4, 5 };

		int n = 4, m = 5;
		for (int i = 0; i < arr.length; i++) {

			if (arr[i] == n)
				n = i;
		}

		for (int i = arr.length - 1; i > 0; i--) {
			if (arr[i] == m)
				m = i;
		}
		System.out.println(n + "..." + m);

		System.out.println("Number of elements " + (m - n + 1));

	}

}
