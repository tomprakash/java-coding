package arrayCoding;

public class Replace_Every_Array_Element_By_Multiplication_Of_Previous_And_Next {

	public static void main(String[] args)

	{
		int arr[] = { 2, 3, 4, 3, 2, 5, 3 };

		int n = arr.length;

		modify(arr, n);

		for (int i = 0; i < arr.length; i++)
			System.out.print(arr[i] + " ");

	}

	public static void modify(int arr[], int n)

	{
		int prev = arr[0];

		arr[0] = arr[0] * arr[1];

		for (int i = 1; i < arr.length - 1; i++)

		{
			int curr = arr[i];

			arr[i] = prev * arr[i + 1];

			prev = curr;
		}

		arr[n - 1] = prev * arr[n - 1];
	}
}
