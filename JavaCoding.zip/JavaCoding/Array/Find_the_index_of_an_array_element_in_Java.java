package Array;
//https://www.geeksforgeeks.org/find-the-index-of-an-array-element-in-java/

public class Find_the_index_of_an_array_element_in_Java {

	public static int Find_the_index_of_an_array_element(int arr[], int n) {
		int index = 0;
		for (int i = 0; i < arr.length; i++) {

			if(arr[i]!=n)
				index++;
			else 
				return index;
		}
		return -1;
	}

	public static void main(String[] args) {
		int arr[] = { 1, 2, 3, 4, 5,0,5,6,-9 };
		System.out.println(Find_the_index_of_an_array_element(arr, -9));
	}

}
