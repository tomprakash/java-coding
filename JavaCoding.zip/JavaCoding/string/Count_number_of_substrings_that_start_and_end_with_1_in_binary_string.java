package string;

public class Count_number_of_substrings_that_start_and_end_with_1_in_binary_string {

	public static int Count_number_of_substrings(String str) {

		int count = 0;
		String temp;
		for (int i = 0; i < str.length(); i++) {
			for (int j = i + 1; j <= str.length(); j++) {
				temp = str.substring(i, j);
				if ((temp.length() >= 2) && (temp.startsWith("1")) && (temp.endsWith("1"))) {
					System.out.println(temp);
					count++;
				}
			}
		}
		return count;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String binary = "1001001110101";
		
		System.out.println(Count_number_of_substrings(binary));

	}

}
