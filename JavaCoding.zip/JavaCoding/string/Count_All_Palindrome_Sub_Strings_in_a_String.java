package string;

public class Count_All_Palindrome_Sub_Strings_in_a_String {

	public static int Count_All_Palindrome_Sub_Strings(String str) {

		int count = 0;
		String temp;
		StringBuffer rev;
		
		String s = str.substring(0, 5);
		System.out.println(s);
		//this is how substring method works , though index 5 is not present
		//in string but it will print till 5-1=4.
		//we need to take care that in second for loop.

		for (int i = 0; i < str.length(); i++) {
			{
				for (int j = i + 1; j <= str.length(); j++) {

					temp = str.substring(i, j);
					System.out.println(i+".."+j+".."+temp);

					if (temp.length() >= 2) {

						rev = new StringBuffer(temp);
						rev = rev.reverse();
						if (rev.toString().equals(temp)){
							System.out.println(rev);
							count++;
						}
					}
				}
			}
		}
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "abaab";

		System.out.println(Count_All_Palindrome_Sub_Strings(str));
	}

}
