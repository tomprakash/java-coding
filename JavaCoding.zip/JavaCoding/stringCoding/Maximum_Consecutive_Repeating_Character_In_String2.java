package stringCoding;
//https://www.geeksforgeeks.org/maximum-consecutive-zeroes-in-concatenated-binary-string/

public class Maximum_Consecutive_Repeating_Character_In_String2 {

	static char maxRepeating(String str) {
		int len = str.length();
		int count = 0;

		// Find the maximum repeating character
		// starting from str[i]
		char res = str.charAt(0);
		for (int i = 0; i < len; i++) {
			int cur_count = 1;
			for (int j = i + 1; j < len; j++) {
				if (str.charAt(i) != str.charAt(j))
					break;
				cur_count++;
			}

			// Update result if required
			if (cur_count > count) {
				count = cur_count;
				res = str.charAt(i);
			}
		}
		return res;
	}

	public static void main(String args[]) {

		System.out.println(maxRepeating("01000001111"));
	}
}
