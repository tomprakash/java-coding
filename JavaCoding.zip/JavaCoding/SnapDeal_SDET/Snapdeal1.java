package SnapDeal_SDET;
//https://www.geeksforgeeks.org/snapdeal-interview-experience-set-17-sdet/
/*Given a question and to execute it on online editor which had all test cases.
Arr1 = {10,20,30,40,50}
Arr2 = {5,10,15,20}
Output Sum of (Max of arr1 divisible by 10 & Max of arr2 divisible by 5)
You can use only one for loop. */
public class Snapdeal1 {

	public static void main(String args[]){
	int	[]arr1 = {10,20,30,40,50};
	int	[]arr2 = {5,10,15,20};
	int maxarr1=arr1[0];
	int maxarr2=arr2[0];
		for(int i=0;i<arr1.length;i++){
			if(arr1[i]%10==0)
				{
				if(arr1[i]>maxarr1)
					maxarr1=arr1[i];
				}
				if( i<arr2.length&&arr2[i]%5==0){
					if(arr2[i]>maxarr2)
						maxarr2=arr2[i];
				}
		}
		System.out.println(maxarr1);
		System.out.println(maxarr2);
		System.out.println(maxarr1+maxarr2);
	}
}
