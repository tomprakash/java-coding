package Array;

import java.util.Arrays;

public class Count_distinct_elements_in_an_array {

	public static void main(String[] args) {
		int arr[] = { 1, 1, 2, 2, 3, 4, 1, 2, 3, 4 };
		int n = arr.length;
		System.out.println(countDistinct(arr, n));
	}

	static int countDistinct(int arr[], int n) {
		// First sort the array so that all occurrences become consecutive
		Arrays.sort(arr);
		// { 1,1,1,2,2,2,3,3,4,4 }; debug using this array
		// Traverse the sorted array
		int res = 0;
		for (int i = 0; i < n; i++) {
		//	System.out.println("inside for loop " + i);

			// Move the index ahead while there are duplicates
			while (i < n - 1 && arr[i] == arr[i + 1]) {
		//		System.out.println(arr[i] + " " + arr[i + 1]);

				i++;
		//		System.out.println("while loop " + i);
			}
			res++;
		//	System.out.println("res " + res);
		}
		return res;
	}

}
