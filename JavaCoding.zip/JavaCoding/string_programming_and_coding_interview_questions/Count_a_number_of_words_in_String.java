package string_programming_and_coding_interview_questions;

public class Count_a_number_of_words_in_String {

	public static int Count_number_of_words_in_String(String str1) {
		int count;
		if (str1.length() == 0)
			return -1;

		String[] arr = str1.split(" ");

		count = arr.length;

		return count;
	}

	public static void main(String[] args) {

		String str1 = "My Name is Tom Prakash Singh";

		System.out.println(Count_number_of_words_in_String(str1));
	}

}
