package overLoading;

public class Method_Overloading_Changing_Data_Type_Of_Arguments {

	 int add(int a, int b) {
		return a + b;
	}

	/*
	 *  double add(int a, int b) { return a + b; }
	 */
	/* just by changing the return type, method overloading is not possible, u
	 need to change arguments also, like in this example, if you uncomment above method u will see a compile
	 time error, Compile Time Error: method add(int,int) is already defined in class Method_Overloading_Changing_Data_Type_Of_Arguments*/
	
	public static void main(String[] args) {

		Method_Overloading_Changing_Data_Type_Of_Arguments obj = new Method_Overloading_Changing_Data_Type_Of_Arguments();
		System.out.println(obj.add(11, 11));

	}
}
