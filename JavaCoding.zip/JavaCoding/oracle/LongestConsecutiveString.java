package oracle;

public class LongestConsecutiveString {

	public static String findLongestConsecutiveString(String str) {

		for (int i = 1; i < str.length() - 1; i++) {
			StringBuilder strnew = new StringBuilder();
			if (((int) str.charAt(i) - (int) str.charAt(i - 1)) == 1) {

				strnew = strnew.append(str.charAt(i));
			}
		}
		return str;
	}

	public static void main(String args[]) {
		System.out.println(findLongestConsecutiveString("abcdghjklm"));
	}
}
