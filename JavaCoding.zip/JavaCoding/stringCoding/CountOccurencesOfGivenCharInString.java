package stringCoding;

import java.util.Scanner;

public class CountOccurencesOfGivenCharInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "abcabccc";
		int count = 0;

		char c = 'c';

		char[] chars = str.toCharArray();

		for (int i = 0; i < chars.length; i++) {
			if (chars[i] == 'c') {
				count++;
			}
		}
		System.out.println(count);
	}

}
