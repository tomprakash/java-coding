package string;

//Replace_all_occurrences_of_a_string_with_space and also extra space in between words
public class Replace_all_occurrences_of_a_string_with_space {

	public static String replaceAllSubString(String str, String subString) {

		str = str.replaceAll(subString, " ");
		str = str.trim();
		str = str.replaceAll(" +", " ");

		char arr[] = str.toCharArray();
		String withoutspace = str.replaceAll("\\s", "");
		/*
		 * for(int i=0;i<arr.length-1;i++) { if(!(arr[i]==' ' && arr[i+1]==' '))
		 * { newstr=newstr+arr[i+1]; System.out.println(newstr); } }
		 */

		// anothe logic to remove extra space between words
		/*
		 * 
		 * String text = "This  is   a    test";
		 * 
		 * while(text.indexOf("  ") >= 0) { text = text.replaceAll("  ", " "); }
		 */
		return str;
	}

	public static void main(String args[]) {

		System.out.println(replaceAllSubString("MYPQNAMEPQISPQTOM", "PQ"));

		System.out.println(replaceAllSubString("OKPQPQMYPQNAMEPQPQISPQTOMPQPQ", "PQ"));
	}
}
