package Array;
//https://www.geeksforgeeks.org/replace-every-element-of-the-array-by-product-of-all-other-elements/

public class Replace_every_element_of_the_array_by_product_of_all_other_elements {

	public static void main(String[] args) {

		int arr[] = { 2, 3, 3, 5, 7 };

		ReplaceElements(arr);

	}

	static void ReplaceElements(int[] arr) {
		int multi = 1;
		for (int i = 0; i < arr.length; i++) {
			multi = multi * arr[i];
		}

		for (int i = 0; i < arr.length; i++) {
			arr[i] = multi / arr[i];
			System.out.println(arr[i]);
		}
	}
}
