package Array;

public class Check_if_an_array_is_palindrome_or_not_without_using_Recursion {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5, 4, 3, 2, 1 };
		System.out.println(checkPalindrome(arr));
	}
	public static boolean checkPalindrome(int arr[]){
		
		int rev[] = new int[arr.length];
		int front = 0;
		int temp;
		int back = arr.length-1;
		while (front < back) {

			for (int i = 0; i < arr.length; i++) {

				temp = arr[front];
				arr[front] = arr[back];
				arr[back] = temp;
			}
			front++;
			back--;
		}
		for (int k = 0; k < arr.length; k++) {

			rev[k]=arr[k];
			
			System.out.println(rev[k]);
		}
		
		for(int j=0;j<arr.length;j++){
			if(arr[j]!=rev[j])
				return false;
		}
		return true;
	}

}
