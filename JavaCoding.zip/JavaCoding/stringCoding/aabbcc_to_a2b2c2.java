package stringCoding;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class aabbcc_to_a2b2c2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "aabbccdde";
		StringBuffer strwithcouont = new StringBuffer();

		HashMap<Character, Integer> map = new HashMap<Character, Integer>();

		for (int i = 0; i < str.length(); i++) {
			if (map.containsKey(str.charAt(i)))
				map.put(str.charAt(i), map.get(str.charAt(i)) + 1);
			else
				map.put(str.charAt(i), 1);
		}

		for (Entry<Character, Integer> entry : map.entrySet()) { // Itrate
																	// through
																	// hashmap

			strwithcouont.append(entry.getKey() + "" + entry.getValue()); // Print
																			// the
																			// key
																			// with
																			// max
																			// value

		}
		System.out.println(strwithcouont);
	}

}
