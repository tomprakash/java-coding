package arrayCoding;

public class FirstNonRepeatinglEment {

	public static void main(String args[])

	{
		int array[] = { 1, 1, 2, 2, 3, 4, 5 };

		int s = array.length;
		int i;
		int j;
		int count;

		for (i = 0; i < s; i++) {
			count = 0;
			for (j = 0; j < s; j++) {
				if (array[i] == array[j]) {
					count++;
				}

			}
			if (count == 1) {
				System.out.println(array[i]);
				break;
			}
		}

	}

}
