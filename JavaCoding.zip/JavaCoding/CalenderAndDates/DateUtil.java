package CalenderAndDates;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

	public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date1, date2;
        try {
            date1 = sdf.parse("11/10/2017");
            date2 = sdf.parse("21/3/2011");
            System.out.println("Difference in days between the dates : "
                    + getDayDifference(date1, date2));
            System.out.println("Difference in months between the dates : "
                    +getMonthDifference(date1, date2));
            System.out.println("Difference in years between the dates : "
                    + getYearDifference(date1, date2));
        } catch (ParseException e) {
            e.printStackTrace();
        }
 
    }
 
    public static int getDayDifference(Date date1, Date date2) {
        long differenceInMillis = date1.getTime() - date2.getTime();
        int differenceInDays = (int) (differenceInMillis / (24 * 60 * 60 * 1000));
        return differenceInDays;
    }
 
    public static int getMonthDifference(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
 
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
 
        int differenceInMonths = cal1.get(Calendar.MONTH)
                - cal2.get(Calendar.MONTH)
                + (cal1.get(Calendar.YEAR) - cal1.get(Calendar.YEAR)) * 12;
        return differenceInMonths;
    }
 
    public static int getYearDifference(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);
 
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);
 
        int diffeInYears = cal1.get(Calendar.YEAR) - cal2.get(Calendar.YEAR);
        return diffeInYears;
    }
}
