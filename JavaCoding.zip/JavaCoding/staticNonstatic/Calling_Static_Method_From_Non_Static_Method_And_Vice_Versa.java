package staticNonstatic;

public class Calling_Static_Method_From_Non_Static_Method_And_Vice_Versa {

	public static void main(String[] args) {
		System.out.println("this is static main method");
		Calling_Static_Method_From_Non_Static_Method_And_Vice_Versa obj = new Calling_Static_Method_From_Non_Static_Method_And_Vice_Versa();
		obj.nonStaticMethod();
	}

	public void nonStaticMethod() {
		System.out.println("this is not static method");
		Calling_Static_Method_From_Non_Static_Method_And_Vice_Versa.staticMethod();
	}

	public static void staticMethod() {
		System.out.println("this is static method");
	}
}
//so both way it possible to do.