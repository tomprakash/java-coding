package stringCoding;

public class ADP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// program asked to print string after last occurence of #.
		String str = "abc#def#ghi#jkl";
		System.out.println(str.lastIndexOf("#"));
		System.out.println(str.substring(str.lastIndexOf("#") + 1));
		System.out.println(str.substring(4));
	}

}
