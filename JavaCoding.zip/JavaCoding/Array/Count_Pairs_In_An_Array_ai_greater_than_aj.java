package Array;

public class Count_Pairs_In_An_Array_ai_greater_than_aj {

	public static void main(String[] args) {

		int arr[] = { 5, 0, 10, 2, 4, 1, 6 };
		int count = 0;
		for (int i = 0; i < arr.length; i++) {

			for (int j = i + 1; j < arr.length; j++) {

				if (arr[i] > arr[j]) {
					count++;
					System.out.println(arr[i] + "..." + arr[j]);
				}
			}
		}

		System.out.println(count);

	}

}
