package stringCoding;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Kth_Non_Repeating_Character {

	public static void main(String[] args) {

		kth_Non_Repeating_Char("geekforgeeks", 4);
	}

	public static char kth_Non_Repeating_Char(String str, int n) {

		LinkedHashMap<Character, Integer> map = new LinkedHashMap<Character, Integer>();

		for (int i = 0; i < str.length(); i++) {

			if (!map.containsKey(str.charAt(i)))
				map.put(str.charAt(i), 1);
			else
				map.put(str.charAt(i), map.get(str.charAt(i)) + 1);
		}
		int count = 0;
		for (Entry<Character, Integer> entry : map.entrySet()) {
			if (entry.getValue() == 1)
				count++;
			if (count == n)
				System.out.println(n + "th" + " non repeating char is " + entry.getKey());
		}
		return '0';
	}
}
