package string;

public class Find_If_String_Has_All_Unique_Characters {

	public static boolean String_Has_All_Unique_Characters(String str) {

		char[] arr = str.toCharArray();

		for (int i = 1; i < arr.length; i++) {

			for (int k = i + 1; k < arr.length; k++) {
				if (arr[i] == arr[k])
					return false;
			}
		}
		return true;
	}

	public static void main(String args[]) {

		System.out.println(String_Has_All_Unique_Characters("abcdef"));
		System.out.println(String_Has_All_Unique_Characters("abcdab"));
	}
}
