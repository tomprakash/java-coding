package com.java2novice.hashset;
 
import java.util.HashSet;
 
public class MyHashSetSearchObject {
 
    public static void main(String a[]){
         
        HashSet<Price1> lhs = new HashSet<Price1>();
        lhs.add(new Price1("Banana", 20));
        lhs.add(new Price1("Apple", 40));
        lhs.add(new Price1("Orange", 30));
        for(Price1 pr:lhs){
            System.out.println(pr);
        }
        Price1 key = new Price1("Banana", 20);
        System.out.println("Does set contains key? "+lhs.contains(key));
    }
}
 
