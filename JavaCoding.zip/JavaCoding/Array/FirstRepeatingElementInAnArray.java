package Array;

public class FirstRepeatingElementInAnArray {
	// this same program can be modified for finding all the repeating elements,
	// by putting break condition inside if loop.
	public static void main(String[] args) {

		int arr[] = { 1, 2, 5, 6, 7, 8, 3, 4, 5, 6 };
		boolean found = false;
		for (int i = 0; i < arr.length-1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					found = true;
				}

			}
			if (found) {
				System.out.println("the first repeated element is " + arr[i]);
				break;
			}

		}

	}

}
