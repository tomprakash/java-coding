package stringCoding;

public class Reverse_Middle_Words_Of_A_String {

	public static String Reverse_Middle_Words(String str) {

		String arr[] = str.split(" ");
		String newstr = arr[0] + " ";
		if (arr.length % 2 == 0)
			return "no middle word";

		for (int i = 1; i < arr.length - 1; i++) {

			newstr = newstr + reverseWords(arr[i]) + " ";

		}
		return newstr + arr[arr.length - 1];
	}

	public static String reverseWords(String word) {

		String rev = "";
		for (int i = word.length() - 1; i >= 0; i--) {
			rev = rev + word.charAt(i);
		}
		return rev;
	}

	public static void main(String args[]) {
		System.out.println(Reverse_Middle_Words("who the    are you"));
	}
}
