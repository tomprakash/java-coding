package string;

import java.util.HashSet;
import java.util.Set;

public class Remove_character {

	public static void main(String[] args) {

		String str1 = "abcdefgh";
		String str2 = "aceg";

		StringBuffer str = new StringBuffer();
		Set<Character> set = new HashSet<Character>();

		for (int i = 0; i < str1.length(); i++) {
			set.add(str1.charAt(i));
		}

		for (int i = 0; i < str2.length(); i++) {
			if (set.contains(str2.charAt(i))){
				char c=str2.charAt(i);
				set.remove(c);
			}
		}
		System.out.println("newstr " + str);
		/*
		 * for (int i = 0; i < str2.length(); i++) { for (int j = 0; j <
		 * str1.length(); j++) { if (str.charAt(i) == str.charAt(j))
		 * str.deleteCharAt(j); } }
		 * 
		 * System.out.println("str " + str);
		 */

	}

}
