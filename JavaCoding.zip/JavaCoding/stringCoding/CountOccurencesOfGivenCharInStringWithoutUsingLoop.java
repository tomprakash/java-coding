package stringCoding;

public class CountOccurencesOfGivenCharInStringWithoutUsingLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "abcccbcb";

		int occurence = str.length() - str.replaceAll("c", "").length();

		System.out.println(occurence);
	}

}
