package overLoading;

public class Method_Overloading_Changing_No_Of_Arguments {

	int add(int a, int b) {
		return a + b;
	}

	int add(int a, int b, int c) {
		return a + b + c;
	}

	int add(int a) {
		return a;
	}

	public static void main(String[] args) {
		Method_Overloading_Changing_No_Of_Arguments obj = new Method_Overloading_Changing_No_Of_Arguments();
		System.out.println(obj.add(11, 11));
		System.out.println(obj.add(11, 11, 11));
		System.out.println(obj.add(11));
	}
}
