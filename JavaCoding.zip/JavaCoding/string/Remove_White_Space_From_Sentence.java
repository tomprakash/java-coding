package string;

public class Remove_White_Space_From_Sentence {

}
