package string;

public class Second_most_repeated_string_in_a_sequence {

	public static void main(String[] args) {

		String str = "aaa bbb ccc bbb aaa  aaa";
	}

}
