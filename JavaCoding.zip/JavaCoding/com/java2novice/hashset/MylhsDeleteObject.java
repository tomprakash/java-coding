package com.java2novice.hashset;
 
import java.util.HashSet;
 
public class MylhsDeleteObject {
 
    public static void main(String a[]){
         
        HashSet<Price2> lhs = new HashSet<Price2>();
        lhs.add(new Price2("Banana", 20));
        lhs.add(new Price2("Apple", 40));
        lhs.add(new Price2("Orange", 30));
        for(Price2 pr:lhs){
            System.out.println(pr);
        }
        Price2 key = new Price2("Banana", 20);
        System.out.println("deleting key from set...");
        lhs.remove(key);
        System.out.println("Elements after delete:");
        for(Price2 pr:lhs){
            System.out.println(pr);
        }
    }
}
 