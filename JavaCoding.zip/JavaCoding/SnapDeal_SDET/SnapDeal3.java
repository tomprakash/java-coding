package SnapDeal_SDET;

//All combination of a string ABCD,A B C D AB AC AD BC BD BCD (Only forward combinations)
public class SnapDeal3 {

	public static void main(String[] args) {
		String str = "ABCD";
		for (int i = 0; i < str.length(); i++) {
			for (int j = i + 1; j <= str.length(); j++) {
				System.out.println(str.substring(i, j));
			}
		}
	}
}
