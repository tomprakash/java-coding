package string;

public class Find_Number_Of_Words_In_String {

	public static int wordcount(String word) {
		if (word == null || word.isEmpty()) {
			return 0;
		}
		int count = 0;
		char ch[] = word.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			ch[i] = word.charAt(i);
			if (((i > 0) && (ch[i] != ' ') && (ch[i - 1] == ' ')) || ((ch[0] != ' ') && (i == 0))) {
				count++;
			}
		}
		return count;
	}

	public static void main(String args[]) {

		System.out.println(wordcount("this  me"));
	}
}

// another way

/*
 * Counting number of words using regular expression.
 */
/*
 * public int countWord(String word) { if (word == null) { return 0; } String
 * input = word.trim(); int count = input.isEmpty() ? 0 :
 * input.split("\\s+").length; return count; }
 */
