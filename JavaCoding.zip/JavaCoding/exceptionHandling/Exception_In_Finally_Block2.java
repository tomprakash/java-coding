package exceptionHandling;

public class Exception_In_Finally_Block2 {

	public static int returnStatementAfterFinallyBlock() {

		try {
			int result = 18 / 0;
		}

		catch (ArithmeticException e) {
			System.out.println("Handled exception");
		}

		finally {
			try {
				int result = 18 / 0;
			}

			catch (ArithmeticException e) {
				throw new RuntimeException("try catch in finally");
			}
		}
		return 0;
		//comment this and see 
	}

	public static void main(String[] args) {

		System.out.println(returnStatementAfterFinallyBlock());
	}

}
