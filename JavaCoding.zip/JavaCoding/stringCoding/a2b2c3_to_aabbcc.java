package stringCoding;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class a2b2c3_to_aabbcc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "a2b2c2d2e1";
		StringBuffer uncompressed = new StringBuffer();

		for (int i = 0; i < str.length() - 1; i++) {
			for (int j = 0; j < i + 1; j++) {

				uncompressed.append(str.charAt(i));
				j = j + 2;
			}
			i = i + 2;
		}
		System.out.println(uncompressed);
	}
}
