package Array;

public class largest_and_smallest_number_in_an_array {

	public static void largest_and_smallest_number_in_array(int array[]) {

		int smallest = array[0];
		for (int i = 0; i < array.length; i++)

		{
			if (array[i] < smallest) {
				smallest = array[i];

			}
		}
		int largest = array[array.length - 1];
		for (int i = 0; i < array.length; i++) {

			if (array[i] > largest) {
				largest = array[i];

			}
		}

		System.out.println("smallest " + smallest + " largest " + largest);
	}

	public static void main(String args[]) {

		int arr[] = { 1, 2, 3, 4, 5, -9, -5, 0, 6 };

		largest_and_smallest_number_in_array(arr);
	}
}
