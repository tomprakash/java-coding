package Array;
//https://www.geeksforgeeks.org/find-element-array-sum-left-array-equal-sum-right-array/

//link  has two different solution spart from this, check it out.

public class Find_an_element_in_array_such_that_sum_of_left_array_is_equal_to_sum_of_right_array {

	public static void main(String[] args) {

		int arr[] = { 2, 3, 4, 1, 4, 5 };
		for (int i = 0; i < arr.length; i++) {

			if (findElement(arr[i], arr)) {
				System.out.println("Element is " + arr[i] + " at index " + i);
				break;
			}

		}

	}

	public static boolean findElement(int k, int arr[]) {

		int index = -1;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == k)
				index = i;
		}
		// System.out.println("Index is " + index);
		int sumleft = 0;
		int sumright = 0;

		for (int j = index - 1; j >= 0; j--) {
			sumleft = sumleft + arr[j];
		}
		// System.out.println("sumleft is " + sumleft);
		for (int i = index + 1; i < arr.length; i++) {
			sumright = sumright + arr[i];
		}
		// System.out.println("sumright is " + sumright);
		if (sumleft == sumright)
			return true;
		return false;
	}
}
