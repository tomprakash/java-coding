package Array;
//https://www.geeksforgeeks.org/sort-even-numbers-ascending-order-sort-odd-numbers-descending-order/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Sort_all_even_numbers_in_ascending_order_and_then_sort_all_odd_numbers_in_descending_order {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		Arrays.sort(arr);
		sortEvenOddAlternative(arr);
	}

	public static void sortEvenOddAlternative(int arr[]) {
		List<Integer> odd = new ArrayList<Integer>();
		List<Integer> even = new ArrayList<Integer>();
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 == 0)
				odd.add(arr[i]);
			else
				even.add(arr[i]);

		}
		System.out.println(odd);
		System.out.println(even);

		for (int i = 0; i < even.size(); i++) {
			System.out.print(even.get(i) + " ");
		}

		for (int i = odd.size() - 1; i >= 0; i--) {
			System.out.print(odd.get(i) + " ");
		}

	}
}
