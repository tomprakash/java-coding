package SnapDeal_SDET;

//Given a string ABCDEF -> I need to tell , if this string has all characters from A-Z
public class SnapDeal2 {
	
	public static void main(String args[]){
		
		String str = "ABCDEF";
		if(check(str))
			System.out.println("true");
		else System.out.println("false");
	}
	public static boolean check(String str) {

		for (int i = 0; i < str.length(); i++) {
			if (!(str.charAt(i) >= 65 && str.charAt(i) <= 90)) {
				return false;

			}

		}
		return true;
	}
}
