package smartInterviews.string;
//https://www.hackerrank.com/challenges/camelcase/problem

public class CamelCase {

	public static void main(String[] args) {

		String str = "redEyesBluesEyesYouWillShutForever";

		System.out.println(camelcase(str));

	}

	static int camelcase(String str) {
		int count = 0;
		for (int i = 0; i < str.length(); i++) {

			if (str.charAt(i) >= 65 && str.charAt(i) <= 90)
				count++;
		}
		if (count > 0)
			return count;
		return -1;

	}

}
