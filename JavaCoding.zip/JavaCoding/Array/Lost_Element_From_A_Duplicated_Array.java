package Array;

import java.util.HashSet;
import java.util.Set;

public class Lost_Element_From_A_Duplicated_Array {

	public static int Find_Lost_Element_From_A_Duplicated_Array(int arr1[], int arr2[]) {

		Set<Integer> set = new HashSet<Integer>();
		for (int i = 0; i < arr1.length; i++) {
			set.add(arr1[i]);
		}
		for (int j = 0; j < arr2.length; j++) {

			if (!set.contains(arr2[j]))
				return arr2[j];
		}
		return 0;
	}

	public static void main(String args[]) {
		int arr1[] = { 2, 3, 4, 5 };
		int arr2[] = { 2, 3, 4, 5, 6 };
		System.out.println(Find_Lost_Element_From_A_Duplicated_Array(arr1, arr2));

	}

}
