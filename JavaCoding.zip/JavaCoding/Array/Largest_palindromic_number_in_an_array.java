package Array;
//https://www.geeksforgeeks.org/largest-palindromic-number-in-an-array/

public class Largest_palindromic_number_in_an_array {

	public static void main(String[] args) {

		int[] arr = { 1, 121, 232, 404, 54545 };
		System.out.println(Largest_palindromic_number(arr));
	}

	public static int Largest_palindromic_number(int arr[]) {

		int max = Integer.MIN_VALUE;
		for (int i = 0; i < arr.length; i++) {

			if (isPalindrome(arr[i])) {
				if (arr[i] > max) {
					max = arr[i];
				}
			}
		}
		return max;

	}

	public static boolean isPalindrome(int n) {
		int num = n;
		int sum = 0;
		while (n > 0) {
			int a = n % 10;
			sum = sum * 10 + a;
			n = n / 10;
		}

		if (num == sum)
			return true;
		return false;
	}
}
