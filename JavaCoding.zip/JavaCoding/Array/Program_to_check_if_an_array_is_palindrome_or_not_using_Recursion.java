package Array;

public class Program_to_check_if_an_array_is_palindrome_or_not_using_Recursion {

	public static void main(String[] args) {

		int[] arr = { 1, 2, 5, 2, 1 };
		StringBuffer str = new StringBuffer();

		for (int i = 0; i < arr.length; i++) {
			str = str.append(arr[i]);
		}
		System.out.println("str " + str);
		StringBuffer rev = str.reverse();
		System.out.println("rev " + rev);
		if (str.equals(rev))
			System.out.println("Palindrome");
		else
			System.out.println("not Palindrome");
	}
}
