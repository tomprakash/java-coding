package Array;

public class Rotation_Count_In_Clockwise_Rotated_Sorted_Array {

	public static int find_Rotation_Count_In_Rotated_Sorted_Array(int arr[]) {
		int min_index = 0;
		int min = arr[0];
		for (int i = 0; i < arr.length; i++) {
			if (min > arr[i]) {
				min = arr[i];
				min_index = i;
			}
		}
		return arr.length - min_index;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 4, 5, 1, 2, 3 };
		System.out.println(find_Rotation_Count_In_Rotated_Sorted_Array(arr));
	}
}
