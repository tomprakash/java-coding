package Array;

import java.util.HashSet;
import java.util.Set;

public class MissingAndRepeatingNumberInArrayTogether {

	public static void main(String[] args) {

		int arr[] = { 1, 3, 3 };

		Set<Integer> set = new HashSet<Integer>();

		for (int i = 0; i < arr.length; i++) {
			if(!set.add(arr[i]));
			System.out.println(arr[i]);
		}
	}

}
