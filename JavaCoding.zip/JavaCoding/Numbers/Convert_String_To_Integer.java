package Numbers;

public class Convert_String_To_Integer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String number = "10";
		int result = Integer.parseInt(number);
		System.out.println(result);
	}

}
