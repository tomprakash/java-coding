package overLoadingOverRiding;

public class Override_a_private_or_static_method_in_Java_Parent_Class {

	public static void main(String[] args) {

	}

	private void privatemethod(int a, String b) {
		System.out.println("This is a private method in parent class");
	}

	public static void staticMethod(int a, int b) {
		System.out.println("This is a static method parent class");
	}
}
