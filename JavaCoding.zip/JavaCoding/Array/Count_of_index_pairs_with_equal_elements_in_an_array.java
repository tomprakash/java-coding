package Array;
//https://www.geeksforgeeks.org/count-index-pairs-equal-elements-array/

public class Count_of_index_pairs_with_equal_elements_in_an_array {

	public static void main(String[] args) {

		int arr[] = { 1, 1, 2, 2, 3, 1 };
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					System.out.println(i + "," + j);
					count++;
				}
			}
		}
		System.out.println("count :" + count);
	}

}
