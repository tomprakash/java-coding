package Array;
//https://www.geeksforgeeks.org/replace-every-element-of-the-array-by-sum-of-all-other-elements/

public class Replace_every_element_of_the_array_by_sum_of_all_other_elements {

	public static void main(String[] args) {

		int arr[] = { 1, 3, 5, 7, 9 };

		ReplaceElements(arr);

	}

	static void ReplaceElements(int[] arr) {
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}

		for (int i = 0; i < arr.length; i++) {
			arr[i] = sum - arr[i];
			System.out.println(arr[i]);
		}
	}

}
