package Array;

public class Given_two_unsorted_arrays_find_all_pairs_whose_sum_is_x {

	public static void pairs_whose_sum_is_x(int arr1[], int arr2[],int n) {

		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr2.length; j++) {

				if(arr1[i]+arr2[j]==n){
					
					System.out.println(arr1[i]+" "+arr2[j]);
				}
			}
		}
	}
	public static void main(String args[]){
		int arr1[]={1,2,3};
		int arr2[]={1,3,4};
		
		pairs_whose_sum_is_x(arr1,arr2,5);
	}
	
}
