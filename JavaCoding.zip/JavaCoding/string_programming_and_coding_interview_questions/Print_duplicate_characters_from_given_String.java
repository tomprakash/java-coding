package string_programming_and_coding_interview_questions;

import java.util.HashMap;
import java.util.Map.Entry;

public class Print_duplicate_characters_from_given_String {

	public static void main(String[] args) {

		String str = "aaassgndhk";

		HashMap<Character, Integer> map = new HashMap<Character, Integer>();

		for (int i = 0; i < str.length() - 1; i++) {
			if (map.containsKey(str.charAt(i)))
				map.put(str.charAt(i), map.get(str.charAt(i)) + 1);
			else
				map.put(str.charAt(i), 1);

		}

		for (Entry<Character, Integer> entry : map.entrySet()) {
			if (entry.getValue() > 1)
				System.out.println(entry.getKey());
		}
	}
}
