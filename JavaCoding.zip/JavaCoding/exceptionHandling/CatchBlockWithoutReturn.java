package exceptionHandling;

//Here why it is not throwing error is bcz we have the catch block to handle exception
//remove catch block and see , last return statement will give error.
public class CatchBlockWithoutReturn {

	public static int returnStatementAfterFinallyBlock() {

		try {
			int result = 18 / 0;
			return result;
		} catch (ArithmeticException e) {
			System.out.println("Handled exception");
		} finally {
			System.out.println("Finally block alwasys executes for source clean up");
		}
		return 0;
	}

	public static void main(String[] args) {
		System.out.println(returnStatementAfterFinallyBlock());
	}

}
