package string;

public class Check_if_a_binary_string_contains_consecutive_same_or_not {

	public static boolean binary_string_contains_consecutive(String str) {

		char arr[] = str.toCharArray();

		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i] == arr[i + 1])
				return false;
		}
		return true;
	}

	public static void main(String args) {

		if (binary_string_contains_consecutive("0101101"))
			System.out.println("valid");
		else
			System.out.println("Invalid");

	}
}
