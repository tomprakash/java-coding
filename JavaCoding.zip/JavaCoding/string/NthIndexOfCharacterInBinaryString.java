package string;

public class NthIndexOfCharacterInBinaryString {

	public static int findIndex(String str, char c, int n) {

		int count = 1;
		int i;
		for (i = 0; i < str.length(); i++) {

			if (str.charAt(i) == c) {
				count++;
			}
			if (count == n) {
				return i;
			}

		}
		return -1;
	}

	public static void main(String arg[]) {

		System.out.println(findIndex("0101011", '1', 5));
	}
}
