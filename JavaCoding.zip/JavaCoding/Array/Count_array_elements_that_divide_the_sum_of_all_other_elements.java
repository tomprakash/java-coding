package Array;
//https://www.geeksforgeeks.org/count-arrays-adjacent-elements-one-divide-another/

public class Count_array_elements_that_divide_the_sum_of_all_other_elements {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5 };
		int sum = 0;
		int newsum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}
		int count = 0;
		for (int i = 0; i < arr.length; i++) {

			newsum = sum - arr[i];
			if (newsum % arr[i] == 0) {
				System.out.println(arr[i]);
				count++;
			}
		}
		System.out.println("count " + count);
	}

}
