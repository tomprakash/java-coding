package arrayCoding;

public class ReverseAnArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int array[] = { 9, 8, 7, 6, 1, 2, 3, 4, 5 };

		int s = 0, e = array.length - 1;

		while (s < e) {
			for (int i = 0; i <= e; i++) {
				int temp = array[i];
				array[i] = array[e];
				array[e] = temp;
				s++;
				e--;
			}
		}
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i] + " ");
		}
	}

}
