package stringCoding;

import java.util.HashMap;
import java.util.Set;

public class FirstNonReaptingCharInString {

	public static void main(String[] args) {

		String s = "abcacbf";
		char[] chrs = s.toCharArray();

		HashMap<Character, Integer> hm = new HashMap<Character, Integer>();

		for (Character ch : chrs)

		{
			if (hm.containsKey(ch)) {
				hm.put(ch, hm.get(ch) + 1);
			} else
				hm.put(ch, 1);

		}

		Set<Character> keys = hm.keySet();
		for (Character ch : keys) {
			if (hm.get(ch) == 1) {
				System.out.println(ch);
				break;
			}
		}

	}

}
