package arrayCoding;

import java.util.Arrays;

public class PairWithTheGivenDifference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int array[] = { 2, 5, 3, 6, 9, 4, 8, 1, 7 };
		int n = 2;
		Arrays.sort(array);

		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				if (i != j && array[i] - array[j] == n)
					System.out.println(array[i] + "... " + array[j]);
			}
		}
	}

}
