package smartInterviews.string;
//https://www.hackerrank.com/challenges/alternating-characters/problem

public class AlternatingCharacters {

	public static void main(String args[]) {

		String str = "AAABBB";

		System.out.println(alternatingCharacters(str));
	}

	static int alternatingCharacters(String s) {

		int count = 0;
		StringBuffer str = new StringBuffer(s);
		for (int i = 0; i < str.length() - 1; i++) {

			if (str.charAt(i) == str.charAt(i + 1)) {
				str.delete(i + 1, i + 2);
				i = -1;
				count++;
			}
		}

		return count;
	}
}
