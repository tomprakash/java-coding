package string_programming_and_coding_interview_questions;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Remove_all_duplicates_from_a_given_string {

	public static void main(String args[]) {

		String str = "aaassgndhk";

		Set<Character> set = new HashSet<Character>();

		for (int i = 0; i < str.length(); i++) {

			if (!set.contains(str.charAt(i))) {
				set.add(str.charAt(i));
			}
		}

		String newstr="";
		Iterator<Character> itr = set.iterator();
		while (itr.hasNext()) {
			newstr=newstr+itr.next();
		}
		
		System.out.println(newstr);
	}
}
