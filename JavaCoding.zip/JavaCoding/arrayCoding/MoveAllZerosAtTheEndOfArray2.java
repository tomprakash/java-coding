package arrayCoding;

public class MoveAllZerosAtTheEndOfArray2 {

	public static void main(String args[]) {

		int[] array = { 1, 2, 3, 5, -1, 4, 0, 6, 0, 9 };

		// Maintaining count of non zero elements

		int count = 0;

		// Iterating through array and copying non zero elements in front of
		// array.

		for (int i = 0; i < array.length; i++) {
			if (array[i] != 0)
				array[count++] = array[i];
		}

		// Replacing end elements with zero

		while (count < array.length - 1)
			array[++count] = 0;

		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}
}
