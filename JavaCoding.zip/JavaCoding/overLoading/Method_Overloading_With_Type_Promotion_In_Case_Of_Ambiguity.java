package overLoading;

public class Method_Overloading_With_Type_Promotion_In_Case_Of_Ambiguity {

	void sum(int a, long b) {
		System.out.println("a method invoked");
	}

	void sum(long a, int b) {
		System.out.println("b method invoked");
	}

	public static void main(String args[]) {
		Method_Overloading_With_Type_Promotion_In_Case_Of_Ambiguity obj = new Method_Overloading_With_Type_Promotion_In_Case_Of_Ambiguity();
		obj.sum(20, 20);// now ambiguity
	}
}
