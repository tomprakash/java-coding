package string;

public class ASCII_Code_Of_A_Character {

	public static void main(String args[]) {
		char ch1 = 'a';
		char ch2 = 'A';

		char ch3 = 'z';
		char ch4 = 'Z';

		char ch5 = 'm';

		char ch6 = 'M';

		System.out.println((int) ch1);
		System.out.println((int) ch2);
		System.out.println((int) ch3);
		System.out.println((int) ch4);
		System.out.println((int) ch5);
		System.out.println((int) ch6);
	}

}
