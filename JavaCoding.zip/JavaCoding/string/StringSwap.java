package string;

public class StringSwap {

	public static void StringSwap(String str1, String str2) {

		System.out.println("String 1st before swap is " + str1);
		System.out.println("String 2nd before swap is " + str2);

		str1 = str1 + str2;// tomprakash

		str2 = str1.substring(0, str1.length() - str2.length());// tom

		str1 = str1.substring(str2.length());// tom

		System.out.println("String 1st after swap is " + str1);
		System.out.println("String 2nd after swap is " + str2);

	}

	public static void main(String args[]) {

		StringSwap("tom", "Prakash");
	}
}
