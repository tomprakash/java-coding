package string;

public class Get_a_string_between_two_characters {

	public static void main(String[] args) {

		String s = "test string (67)";
		String c1 = "(";
		String c2 = ")";

		System.out.println(getStringBetweenTwoChars(s, c1, c2));
	}

	public static String getStringBetweenTwoChars(String input, String startChar, String endChar) {

		int j = input.indexOf(startChar);
		int k = input.indexOf(endChar);
		return input.substring(j+1, k);
	}

}
