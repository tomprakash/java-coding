package practicaAgain;

public class Stringswap {

	public static void main(String args[]) {
		String str1= "tom";
		String str2= "prakash";
		
		System.out.println("before swap"+str1+ "...."+str2);
		
		str2=str1+str2;
		str1=str2.substring(str1.length());
		str2=str2.substring(0,str2.length()-str1.length());
	
		System.out.println(str1);
		System.out.println(str2);
		
	}
}
