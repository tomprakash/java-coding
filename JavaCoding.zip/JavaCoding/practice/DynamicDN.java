package practice;

import java.util.Random;

public class DynamicDN {

	public String generatedynamicDN2(){

		int count=9;
		String randomNumString = "010";
		
		Random r = new Random();

	    //Generate the remaining digits between 0-9
	    for(int x = 1; x < count; x++){
	        randomNumString += r.nextInt(9);
	    }

	    return randomNumString.toString();
	   // return Long.toString(randomNumString);
	}
	
	public static void main(String args[])
	
	{
		DynamicDN dn = new DynamicDN();
		String a= dn.generatedynamicDN2();
		System.out.println("a is "+a);
	}
}
