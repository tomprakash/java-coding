package Array;

import java.util.Arrays;

public class Print_Array_In_Wave_Form {

	public static void main(String[] args) {

		int arr[] = { 10, 20, 30, 40, 50, 60, 70, 80 };
		// waveform {20,10,40,30,60,50,80,70}
		Arrays.sort(arr);
		int temp;

		for (int i = 0; i < arr.length - 1; i++) {
			// or for (int i=0; i<n-1; i += 2) {
			temp = arr[i];
			arr[i] = arr[i + 1];
			arr[i + 1] = temp;
			++i;
		}

		for (int i = 0; i < arr.length; i++) {

			System.out.println(arr[i]);
		}
	}

}
