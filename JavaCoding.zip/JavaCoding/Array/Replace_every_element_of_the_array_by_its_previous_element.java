package Array;
//https://www.geeksforgeeks.org/replace-every-element-of-the-array-by-its-previous-element/

public class Replace_every_element_of_the_array_by_its_previous_element {

	public static void main(String[] args) {

		int arr[] = { 2, 7, 4, 0, 8 };

		replace_with_previous_element(arr);
	}

	public static void replace_with_previous_element(int arr[]) {
		int k = arr.length - 1;
		for (int i = 0; i < arr.length - 1; i++) {

			arr[k] = arr[k - 1];
			k--;
		}

		arr[0] = -1;

		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}
}
