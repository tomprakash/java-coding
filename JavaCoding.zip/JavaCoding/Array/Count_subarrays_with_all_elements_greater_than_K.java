package Array;

public class Count_subarrays_with_all_elements_greater_than_K {

	public static void main(String[] args) {

		int arr[] = { 3, 4, 5, 6, 7, 2, 10, 11 };
		int K = 5;
		int count = 0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>5)
				count++;
			continue;
		}
		
		System.out.println("count: "+count);
	}

}
