package string;

public class Removing_punctuations_from_a_given_string {

	public static void main(String args[]) {
		String input = "%welcome' to @geeksforgeek<s";
		StringBuffer str = new StringBuffer();
		for (int i = 0; i < input.length(); i++) {

			if ((input.charAt(i) >= 65 && input.charAt(i) <= 90) || (input.charAt(i) >= 97 && input.charAt(i) <= 122) || input.charAt(i)==' ')
				str = str.append(input.charAt(i));
		}
		
		System.out.println(str);
	}
}
