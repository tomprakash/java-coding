package stack;
//https://www.geeksforgeeks.org/program-to-reverse-a-linked-list-using-stack/

//see other links which are on left side and bottom of this problem in geekforgeeks

public class Program_to_reverse_a_linked_list_using_Stack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
