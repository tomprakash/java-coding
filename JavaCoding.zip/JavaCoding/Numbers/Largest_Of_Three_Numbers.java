package Numbers;

public class Largest_Of_Three_Numbers {

	public static void main(String args[]) {
		int num1 = 2, num2 = 1, num3 = 3;
		int result;
		result = num1 > (num3 > num2 ? num3 : num2) ? num1 : ((num2 > num3) ? num2 : num3);
		System.out.println(result);

	}
}
