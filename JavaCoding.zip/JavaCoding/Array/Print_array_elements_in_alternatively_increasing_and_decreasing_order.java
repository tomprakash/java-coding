package Array;

public class Print_array_elements_in_alternatively_increasing_and_decreasing_order {

	public static int [] array_elements_in_alternatively_increasing_and_decreasing_order(int arr []){
		
		
		return arr;
		
		
	}
	
}
