package Amazon_SDET;

public class Print_All_Anagrams_In_String {

	public static void main(String[] args) {

		String str = "State is Taste and Cider is Cried also Dusty can be Study and Night is Thing";

	}

	/*
	 * public static isAnagram(String str){
	 * 
	 * char []arr=str.toCharArray(); StringBuffer strbuf = new
	 * StringBuffer(str); str.sort(); }
	 */
}
