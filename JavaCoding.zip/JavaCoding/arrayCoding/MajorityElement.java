package arrayCoding;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class MajorityElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = { 1, 2, 1, 2, 2, 2, 3, 4, 5, 2, 3, 2, 2, 2, 2 };
		int j = arr.length / 2;
		System.out.println(j);

		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (Integer a : arr) {
			if (map.containsKey(a)) {
				map.put(a, map.get(a) + 1);
			} else {
				map.put(a, 1);
			}
		}
		System.out.println(map);
		Set<Entry<Integer, Integer>> entryset = map.entrySet();
		for (Entry<Integer, Integer> entry : entryset) {
			if (entry.getValue() > j) {
				System.out.println("Majority elemtn is " + entry.getKey());
			}
		}
	}

}
