package Array;

public class Find_the_minimum_distance_between_two_numbers {

	public static void main(String[] args) {

		int arr[] = { 3, 5, 4, 2, 6, 5, 6, 6, 5, 4, 8, 3 };
		int x = 3, y = 6;

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == x) {
				x = i;
				break;
			}
		}
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == y) {
				y = i;
				break;
			}
		}
		System.out.println("Minimum difference between x and y is : " + (y - x));
	}

}
