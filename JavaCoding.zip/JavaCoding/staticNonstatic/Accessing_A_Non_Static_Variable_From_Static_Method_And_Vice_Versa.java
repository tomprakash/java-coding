package staticNonstatic;
//both way it is not possible

//https://javarevisited.blogspot.com/2012/02/why-non-static-variable-cannot-be.html#axzz5oItGljF8

//https://www.quora.com/How-do-I-access-a-non-static-variable-in-a-static-method

public class Accessing_A_Non_Static_Variable_From_Static_Method_And_Vice_Versa {

	int b = 10;
	static int k = 9;

	public static void main(String[] args) {
		int i = 10;
		// System.out.println("this is static main method");
		Accessing_A_Non_Static_Variable_From_Static_Method_And_Vice_Versa obj = new Accessing_A_Non_Static_Variable_From_Static_Method_And_Vice_Versa();
		// obj.a;
		System.out.println(obj.b);
//		System.out.println(Accessing_A_Non_Static_Variable_From_Static_Method_And_Vice_Versa.b);
		System.out.println(Accessing_A_Non_Static_Variable_From_Static_Method_And_Vice_Versa.k);
		obj.nonStaticMethod();
	}

	public void nonStaticMethod() {
		int a = 10;
		Accessing_A_Non_Static_Variable_From_Static_Method_And_Vice_Versa obj = new Accessing_A_Non_Static_Variable_From_Static_Method_And_Vice_Versa();
		System.out.println(obj.k);
		System.out.println(Accessing_A_Non_Static_Variable_From_Static_Method_And_Vice_Versa.k);

	}
}
