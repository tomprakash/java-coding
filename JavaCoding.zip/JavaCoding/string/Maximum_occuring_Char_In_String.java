package string;

public class Maximum_occuring_Char_In_String {

	public static void main(String args[]) {

		String str = "ggggkjhkkkkjjjjjjhs";

		char[] arr = str.toCharArray();
		char max1 = 0;
		int max=Integer.MIN_VALUE;

		for (int i = 0; i < arr.length; i++) {
			int count=1;
			for (int j = i + 1; j < arr.length; j++) {

				if(arr[i]==arr[j])
					count++;
			}
			if(count>max){
				max=count;
			max1=arr[i];
			}
		}
		
		System.out.println(max);
		System.out.println(max1);
	}
}
