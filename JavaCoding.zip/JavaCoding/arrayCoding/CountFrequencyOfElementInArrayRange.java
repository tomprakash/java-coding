package arrayCoding;

import java.util.Arrays;
import java.util.HashMap;

public class CountFrequencyOfElementInArrayRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// asked in amazon.

		int array[] = { 2, 3, 2, 4 };

		int s = array.length;

		for (int a = 1; a <= s; a++) {
			int count = 0;
			for (int i = 0; i < s; i++) {

				if (array[i] == a) {
					count++;
				}
			}
			System.out.println(a + " : " + count);
		}

	}

}
