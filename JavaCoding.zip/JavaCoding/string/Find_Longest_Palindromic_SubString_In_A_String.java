package string;

public class Find_Longest_Palindromic_SubString_In_A_String {

	public static void main(String[] args) {
		String str = "abaab";
		String longest_Palindromic_SubString = "";
		int max = 0;
		for (int i = 0; i < str.length(); i++) {
			{
				String sub = null;
				for (int j = i + 1; j <= str.length(); j++) {

					sub = str.substring(i, j);
					String rev = findRev(sub);

					if (sub.length() > 1 && rev.equals(sub)) {
						System.out.println(sub);
						if (sub.length() > max) {
							max = sub.length();
							longest_Palindromic_SubString = sub;
						}

					}
				}
			}
		}
		System.out.println("longest_Palindromic_SubString " + longest_Palindromic_SubString);

	}

	public static String findRev(String str) {
		String rev = "";
		for (int k = str.length() - 1; k >= 0; k--) {
			rev = rev + str.charAt(k);
		}
		return rev;
	}

}
