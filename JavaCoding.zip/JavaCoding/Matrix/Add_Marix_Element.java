package Matrix;

public class Add_Marix_Element {

	public static void main(String[] args) {

		int a[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		int b[][] = { { 1, 1, 1 }, { 1, 1, 1 }, { 1, 1, 1 } };
		int sumMatrix[][] = new int[a.length][a[0].length];

		// System.out.println(a.length);
		// System.out.println(a[0].length);

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[0].length; j++) {
				sumMatrix[i][j] = a[i][j] + b[i][j];
				System.out.print(sumMatrix[i][j] + " ");
			}
			System.out.println();
		}
	}
}
