package string;

//This solution works when there are other uppercase characters and we want only the first letter to be uppercase
//[a-z]97 to 122
//[A-Z]65 to 90
public class convert_First_Character_Uppercase_In_A_Sentence {

	public static String convert_First_Character_Uppercase(String str) {

		// Create a char array of given String
		char ch[] = str.toCharArray();

		for (int i = 0; i < ch.length - 1; i++) {

			// If first character of a word is found
			if ((i == 0 && ch[i] != ' ') || (ch[i] != ' ' && ch[i - 1] == ' ')) {

				// If it is in lower-case
				if (ch[i] >= 'a' && ch[i] <= 'z') {

					// Convert into Upper-case
					ch[i] = (char) (ch[i] - 'a' + 'A');
				}
			}
			// If apart from first character
			// Any one is in Upper-case
			else if (ch[i] >= 'A' && ch[i] <= 'Z') {
				// Convert into Lower-Case
				ch[i] = (char) (ch[i] + 'a' - 'A');
			}
		}
		String strnew = new String(ch);
		return strnew;
	}
	// Convert the char array to equivalent String

	public static void main(String args[]) {
		System.out.println(convert_First_Character_Uppercase("my name is Tom prAKash"));
	}

}
