package Array;

public class Smallest_Pair_Sum_in_an_array {

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5, 6, 7 };
		int min = Integer.MAX_VALUE;
		for (int i = 0; i < arr.length; i++) {
			int currentmin;
			for (int j = i + 1; j < arr.length; j++) {
				currentmin = arr[i] + arr[j];
				if (currentmin < min)
					min = currentmin;
			}
		}
		
		System.out.println(min);
	}

}
