package overLoading;

public class Method_Overloading_With_Type_Promotion {
	void sum(int a, long b) {
		System.out.println(a + b);
	}

	void sum(int a, int b, int c) {
		System.out.println(a + b + c);
	}

	public static void main(String args[]) {
		Method_Overloading_With_Type_Promotion obj = new Method_Overloading_With_Type_Promotion();
		obj.sum(20, 20);// now second int literal will be promoted to long
		obj.sum(20, 20, 20);
	}
}