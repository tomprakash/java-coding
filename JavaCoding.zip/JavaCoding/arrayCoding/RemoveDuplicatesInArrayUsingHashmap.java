package arrayCoding;

import java.util.HashSet;

public class RemoveDuplicatesInArrayUsingHashmap {

	public static int[] removeDuplicates(int[] input) {
		HashSet<Integer> H = new HashSet<Integer>();
		for (Integer integer : input) {
			System.out.println(integer);
			H.add(integer);
		}
		int result[] = new int[H.size()];
		int counter = 0;
		for (Integer x : H) {
			result[counter++] = x;
		}
		return result;
	}

	public static void main(String args[])

	{
		int[] arr = { 1, 2, 3, 1, 2, 4, 5, 6 };

		int n = arr.length;

		RemoveDuplicatesInArrayUsingHashmap dp = new RemoveDuplicatesInArrayUsingHashmap();

		int[] result = dp.removeDuplicates(arr);

		System.out.println(result);
	}

}
