package fileInputOutput;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Find_the_first_unique_occurrence_of_a_word_in_a_file {

	public static void main(String[] args) throws IOException {		
		BufferedReader reader=new BufferedReader(new FileReader("C://Users//612151220//Mobile//automation//xml//modify.xml"));
		String s="";
	//	int temp=0;
		List<String> list=new ArrayList<>();
		String[] s2 = null;
		Map<String, Integer> map=new LinkedHashMap<>();
		while((s=reader.readLine())!=null){
			s2=s.split(" ");
		}
		for (int i = 0; i < s2.length; i++) {			
				if(!map.containsKey(s2[i])){
					map.put(s2[i], 1);
				}else{
					map.put(s2[i], map.get(s2[i]) +1);
				}			
		}
		
		for (Map.Entry<String , Integer> entry: map.entrySet()){
			if(entry.getValue()==1){
				list.add(entry.getKey());
			}
		}		
		System.out.println(list.get(0));
	}
}
