package Array;

public class Find_bitonic_point_in_given_bitonic_sequence {

	public static void main(String args[]) {

		int arr[] = { 3, 5, 7, 8, 4, 2, 1 };

		for (int i = 1; i < arr.length - 1; i++) {
			if (arr[i] > arr[i + 1] && arr[i] > arr[i - 1])
				System.out.println(arr[i]);
			System.out.println("Bitonic index "+i);
		}
	}

}
