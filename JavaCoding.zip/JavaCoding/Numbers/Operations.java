package Numbers;

public class Operations {

	public static void main(String[] args) {

		float result;
		result = 5/2;
		System.out.println(result);
		result = 1 / 64;
		System.out.println(result);
		System.out.println(-3/2);
		System.out.println(-1/2);
		// System.out.println(1/(float)2);
	}
}
