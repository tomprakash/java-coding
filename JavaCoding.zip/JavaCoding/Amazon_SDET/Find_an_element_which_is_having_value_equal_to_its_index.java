package Amazon_SDET;
//https://www.geeksforgeeks.org/amazon-interview-experience-set-182-for-sdet-1/
public class Find_an_element_which_is_having_value_equal_to_its_index {

	public static void main(String[] args) {

		int index =0;
		int arr[]={9,8,1,2,-1,-3,6,7};
		
		for(int i=0;i<arr.length;i++){
			
			if(arr[i]==index){
				System.out.println(arr[i]);
			}
			index++;
		}
	}

}
