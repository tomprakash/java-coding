package string;
//https://stackoverflow.com/questions/15111420/how-to-check-if-a-string-contains-only-digits-in-java

public class Check_If_String_Contains_Only_Digits {

	public static void main(String args[]) {
		// String regex = "[0-9]"; // this doesn't work
		// String regex = "\\d+"; // this will also work,, refer to links above.
		String regex = "[0-9]+";
		String data = "23343453";
		System.out.println(data.matches(regex));
	}
}
