package arrayCoding;

public class MinimumDifferenceBetweenTwoElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int array[] = { 2, 8, -1 };
		int min = Integer.MAX_VALUE;

		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (Math.abs(array[i] - array[j]) < min)
					min = Math.abs(array[i] - array[j]);
			}
		}
		System.out.println("the minimum difference between two elements is " + min);
	}

}
