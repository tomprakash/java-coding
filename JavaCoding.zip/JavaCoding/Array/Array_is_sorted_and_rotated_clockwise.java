package Array;

public class Array_is_sorted_and_rotated_clockwise {

	public static void check_If_Array_is_sorted_and_rotated_clockwise(){
		
		
	}
	
	public static void main(String args[]){
		
	}
	
}
