package smartInterviews.string;
//https://www.hackerrank.com/challenges/reduced-string/problem

public class Super_Reduced_String {

	public static void main(String[] args) {

		String str = "aaaabbbccd";

		System.out.println(superReducedString(str));

	}

	static String superReducedString(String str) {
		StringBuffer s = new StringBuffer(str);
		for(int i=0;i<s.length()-1;i++)
	      { 
	        if(s.charAt(i)==s.charAt(i+1))
	        { 
	            s.delete(i,i+2);
	            i=-1;
	            System.out.println(s);
	    
	        }
	       
	      }
		if (s.length() == 0)
			return "Empty String";
		else
			return s.toString();
	}
}
