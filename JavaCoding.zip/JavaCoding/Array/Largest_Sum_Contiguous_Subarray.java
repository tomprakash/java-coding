package Array;
//https://www.geeksforgeeks.org/largest-sum-contiguous-subarray/

// look into the link for all negative elements in the array and to print the indices of elements

public class Largest_Sum_Contiguous_Subarray {

	public static void main(String[] args) {

		int arr[] = { -2, -3, 4, -1, -2, 1, 5, -3 };

		System.out.println(maxSubArraySum(arr));

	}

	public static int maxSubArraySum(int arr[]) {

		int max_so_far = 0;
		int max_ending_here = 0;
		for (int i = 0; i < arr.length; i++) {
			max_ending_here = max_ending_here + arr[i];
			if (max_ending_here < 0)
				max_ending_here = 0;
			if (max_so_far < max_ending_here)
				max_so_far = max_ending_here;
		}

		return max_so_far;

	}

}
