package recursion;
//https://www.geeksforgeeks.org/recursive-function-check-string-palindrome/

public class Recursive_function_to_check_if_a_string_is_palindrome {

	public static void main(String[] args) {

		// String str = "malayalam";
		String str = "1919191";
		int low = 0;
		int high = str.length() - 1;
		System.out.println(recursivePalindrome(str, low, high));
	}

	public static boolean recursivePalindrome(String str, int low, int high) {

		if (str.charAt(low) != str.charAt(high))
			return false;

		if (low < high)
			return recursivePalindrome(str, low + 1, high - 1);

		return true;
	}
}
