package string;

//https://www.geeksforgeeks.org/check-is-it-possible-to-rearrange-a-binary-with-alternate-0s-and-1s/
public class Check_if_it_is_possible_to_rearrange_a_binary_string_with_alternate_0s_and_1s {

	public static void main(String[] args) {

		String binary = "10101010101";
		int zero = 0;
		int one = 0;
		for (int i = 0; i < binary.length(); i++) {

			if (binary.charAt(i) == '1')
				one++;
			else
				zero++;
		}

		if (one == zero)
			System.out.println("Possible");
		else if (Math.abs(one - zero) == 1)
			System.out.println("Possible");
		else
			System.out.println("Not possible");

	}

}
