package string;

public class Find_All_Palindromic_SubString_In_A_String {

	public static void main(String[] args) {

		String str = "abaab";
		

		for (int i = 0; i < str.length(); i++) {
			{
				String sub = null;
				for (int j = i + 1; j <= str.length(); j++) {

					sub = str.substring(i, j);
					String rev = findRev(sub);
					if (sub.length()>1 && rev.equals(sub)) {
						System.out.println(sub);
					}
				}
			}
		}

	}

	public static String findRev(String str) {
		String rev = "";
		for (int k = str.length() - 1; k >= 0; k--) {
			rev = rev + str.charAt(k);
		}
		return rev;
	}

}
