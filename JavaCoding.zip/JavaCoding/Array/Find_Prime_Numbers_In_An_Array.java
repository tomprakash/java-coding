package Array;

public class Find_Prime_Numbers_In_An_Array {

	public static void main(String[] args) {

		int arr[] = { 3, 5, 9, 13, 17, 35, 71 };
		findPrimeNumbers(arr);
	}

	public static void findPrimeNumbers(int arr[]) {

		for (int i = 0; i < arr.length; i++) {
			if (isPrime(arr[i]))
				System.out.println(arr[i]);
		}
	}

	public static boolean isPrime(int k) {

		for (int i = 2; i < k / 2; i++) {
			if (k % i == 0)
				return false;
		}
		return true;

	}
}
