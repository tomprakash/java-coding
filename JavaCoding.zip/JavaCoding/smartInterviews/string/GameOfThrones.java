package smartInterviews.string;

import java.util.Arrays;

//https://www.hackerrank.com/challenges/game-of-thrones/problem

public class GameOfThrones {

	public static void main(String[] args) {

		String str = "cdcdcdcdeeeef";
		// palindrome from the string: ddcceefeeccdd.
		System.out.println(gameOfThrones(str));

	}

	static String gameOfThrones(String str) {
		char arr[] = str.toCharArray();
		Arrays.sort(arr);
		String strnew = new String(arr);
		StringBuffer s = new StringBuffer(strnew);
		for (int i = 0; i < s.length() - 1; i++) {

			if (s.charAt(i) == s.charAt(i + 1)) {
				s.delete(i, i + 2);
				i = -1;
			}
		}
		if (s.length() <= 1)
			return "Yes";
		return "No";

	}
}

//another solution

/*Set<Character> set = new HashSet<Character>();
for(Character ch : str.toCharArray()){
    if(set.contains(ch)){
        set.remove(ch);
    }else{
        set.add(ch);
    }
}

System.out.println((set.size()<=1)?"YES":"NO");*/

//another solution

/*HashSet<Character> hashSet = new HashSet<Character>();
for(int i=0;i<word.length();i++){
    if(hashSet.size() > (word.length()-i) + 1) return false;
    char character = word.charAt(i);
    if(hashSet.contains(character)){
        hashSet.remove(character);
    }else{
        hashSet.add(character);
    }
}
return hashSet.size() == word.length()%2;*/