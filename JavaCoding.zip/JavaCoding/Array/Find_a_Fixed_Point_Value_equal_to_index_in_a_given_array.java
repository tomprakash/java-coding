package Array;
//https://www.geeksforgeeks.org/find-a-fixed-point-in-a-given-array/

public class Find_a_Fixed_Point_Value_equal_to_index_in_a_given_array {

	public static void main(String[] args) {

		int arr[] = { 5, -9, 2, 3, 8, 2, 7, -4 };

		int fixed_point = 0;
		for (int i = 0; i < arr.length; i++) {

			if (arr[i] == i)
				fixed_point = i;
		}
		
		System.out.println("fixed_point "+fixed_point);
	}

}
