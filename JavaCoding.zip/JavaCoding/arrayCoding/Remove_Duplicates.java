package arrayCoding;

import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;

public class Remove_Duplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = { 1, 2, 3, 4, 1, 2, 3, 6, 7 };

		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < arr.length; i++) {
			if (map.containsKey(arr[i]))
				map.put(arr[i], map.get(arr[i]) + 1);

			else
				map.put(arr[i], 1);
		}

		Set<Entry<Integer, Integer>> entrySet = map.entrySet();
		for (Entry<Integer, Integer> entry : entrySet)

			System.out.println(entry.getKey());

	}
}
