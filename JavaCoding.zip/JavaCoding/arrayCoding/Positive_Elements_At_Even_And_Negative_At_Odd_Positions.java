package arrayCoding;

public class Positive_Elements_At_Even_And_Negative_At_Odd_Positions {

	public static void main(String args[]) {
		int arr[] = { 1, -3, 5, 6, -3, 6, 7, -4, 9, 10 };
		int n = arr.length;

		rearrange(arr, n);
		for (int i = 0; i < n; i++)
			System.out.print(arr[i] + " ");
	}

	public static void rearrange(int arr[], int n) {

	}
}
