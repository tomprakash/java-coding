package exceptionHandling;
//if Exception occures in finaly block it will be handled by JVM
//note that here we are not returning any value still it is compiling
public class Exception_In_Finally_Block {

	public static int returnStatementAfterFinallyBlock() {

		try {
			int result = 18 / 0;
		}

		catch (ArithmeticException e) {
			System.out.println("Handled exception");
		}

		finally {
			throw new RuntimeException("Finally block alwasys executes for source clean up");
		}
	}

	public static void main(String[] args) {

		System.out.println(returnStatementAfterFinallyBlock());
	}

}
