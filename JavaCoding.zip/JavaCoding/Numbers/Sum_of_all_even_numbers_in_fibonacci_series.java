package Numbers;

public class Sum_of_all_even_numbers_in_fibonacci_series {

	public static int Find_the_sum_of_all_even_numbers_in_fibonacci_series(int n) {
		int a = 0, b = 0, c = 1, sum = 0;
		for (int i = 0; i < n; i++) {

			a = b;
			b = c;
			c = a + b;
			System.out.println(a);
			if (a % 2 == 0) {
				sum = sum + a;
			}
		}
		return sum;

	}

	public static void main(String[] args) {

		System.out.println(Find_the_sum_of_all_even_numbers_in_fibonacci_series(7));
	}

}
