package string_programming_and_coding_interview_questions;

public class Reverse_the_words_in_a_given_String_sentence {

	public static String Reverse_the_words_in_a_sentence(String str){
		
		String rev = "";
		
		for(int i=str.length()-1;i>=0;i--){
			
			rev = rev+str.charAt(i);
		}
		return rev;
	}
	
	public static void main(String[] args) {

		String str = "my name is tom";
		System.out.println(Reverse_the_words_in_a_sentence(str));

	}

}
