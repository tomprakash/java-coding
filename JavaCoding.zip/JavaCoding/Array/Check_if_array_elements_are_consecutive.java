package Array;

import java.util.Arrays;

public class Check_if_array_elements_are_consecutive {

	public static void main(String[] args) {

		int arr[] = { 5, 4, 1, 3, 2 };
		Arrays.sort(arr);
		System.out.println(checkConsecutive(arr));

	}

	public static boolean checkConsecutive(int arr[]) {

		for (int i = 1; i < arr.length; i++) {
			if (arr[i] - arr[i-1] != 1)
				return false;
		}
		return true;
	}
}
