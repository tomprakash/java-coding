package Array;

public class find_all_pairs_array_whose_sum_is_equal_to_given_number {

	public static void find_all_pairs(int arr[], int n) {

		for (int i = 0; i < arr.length; i++) {
			for (int k = i + 1; k < arr.length; k++)

				if (arr[i] + arr[k] == n)
					System.out.println(arr[i] + "and" + arr[k]);
		}

	}

	public static void main(String args[]) {

		int arr[] = { 2, 4, 3, 5, 7, 8, 9 };

		int n = 7;

		find_all_pairs(arr, n);
	}
}
