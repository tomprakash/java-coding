package Array;

class Program_to_check_if_an_array_is_bitonic_or_not {

	static int checkBitonic(int arr[], int n) {
		int pivot = 0;
		for (int i = 1; i < arr.length - 1; i++) {
			if (arr[i] > arr[i + 1] && arr[i] > arr[i - 1]) {
				System.out.println("pivot element " + arr[i]);
				pivot = i;
				System.out.println("pivot index " + pivot);
				break;
			}
		}
		// below is the for loop syntax for 2 variables;
		/*
		 * for(int i=pivot-1,j=pivot+1;i>=0||j<arr.length-1;j++,i--){
		 * if(arr[i]<arr[i-1]||arr[j]<arr[j+1]) return -1; }
		 */

		for (int i = pivot - 1; i > 0; i--) {
			if (arr[i] < arr[i - 1])
				return -1;
		}

		for (int i = pivot + 1; i < arr.length - 1; i++) {
			if (arr[i] < arr[i + 1])
				return -1;
		}
		return 1;

	}

	public static void main(String args[]) {
		int arr[] = { -3, 5, 7, 20, 17, 5, 1 };

		int n = arr.length;

		System.out.println((checkBitonic(arr, n) == 1) ? "YES" : "NO");
	}
}
