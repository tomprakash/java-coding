package stringCoding;

public class ReverseEachWordOfAnString {

	public static void main(String[] args) {
		String str = "My Name is Khan";

		String words[] = str.split(" ");

		String reverseString = "";

		for (int i = 0; i < words.length; i++) {
			String word = words[i];
			String reverseword = "";
			for (int k = word.length() - 1; k >= 0; k--) {
				reverseword = reverseword + word.charAt(k);
			}
			reverseString = reverseString + reverseword + " ";
		}
		System.out.println(str);
		System.out.println(reverseString.trim());
	}

}
