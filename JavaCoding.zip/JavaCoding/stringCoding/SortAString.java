package stringCoding;

import java.util.Arrays;

public class SortAString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "geekforgeeks";

		char[] chars = str.toCharArray();

		Arrays.sort(chars);

		System.out.println(new String(chars));
	}

}
