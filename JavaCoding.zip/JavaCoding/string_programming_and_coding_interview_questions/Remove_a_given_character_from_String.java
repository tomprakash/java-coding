package string_programming_and_coding_interview_questions;

public class Remove_a_given_character_from_String {

	
	public static String Remove_given_character_from_String(String str,char c){
		
		String newstr="";
		
		for(int i=0;i<str.length();i++){
			
			if(!(str.charAt(i)==c)){
				newstr=newstr+str.charAt(i);
			}
		}
		return newstr;
		
	}
	public static void main(String[] args) {

		String str = "Tomprakash";
		char c= 'T';
		System.out.println(Remove_given_character_from_String(str,c));
	}

}
