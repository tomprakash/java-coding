package Numbers;

public class SwapTwoNumbers {

	public static void main(String args[]) {

		int a = 5, b = 7;

		System.out.println("Before swap " + "a " + a + " b " + b);

		a = a + b;// 12
		b = a - b;// 5
		a = a - b;// 7

		System.out.println("After swap " + "a " + a + " b " + b);
	}
}
