package com.java2novice.arraylist;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Remove_duplicates_from_a_sorted_linked_list {

	public static void main(String args[]) {

		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(1);
		list.add(2);
		list.add(2);
		list.add(1);
		list.add(3);
		list.add(3);
		
		Set<Integer> set = new HashSet<Integer>(list);
		System.out.println(set);
	}
}
