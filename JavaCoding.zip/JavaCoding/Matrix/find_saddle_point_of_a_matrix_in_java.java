package Matrix;

public class find_saddle_point_of_a_matrix_in_java {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[][]={{1,2,3},{4,5,6},{7,8,9}};
	}

}
