package arrayCoding;

public class SegregateZerosAndOnceInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] array = { 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1 };

		int count = 0;

		int size = array.length;

		for (int i = 0; i < size; i++) {
			if (array[i] != 0)
				array[count++] = array[i];
		}

		for (int i = count; i < size; i++) {
			array[i] = 0;
		}

		for (int i = 0; i < size; i++) {
			System.out.println(" " + array[i]);
		}
	}

}
