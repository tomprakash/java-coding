package string;

public class Reverse_string_preserving_space_positions {

	public static void main(String[] args) {

		reverseString("internship at geeks for geeks");
	}

	public static void reverseString(String str) {

		char[] inputArray = str.toCharArray();
		char[] result = new char[inputArray.length];

		for (int i = 0; i < str.length(); i++) {

			if (inputArray[i] == ' ')
				result[i] = ' ';
		}
		int j = inputArray.length - 1;
		for (int i = 0; i < str.length(); i++) {
			// Ignore spaces in input string 
			if (inputArray[i] != ' ') {
			      // ignore spaces in result.
				if (result[j] == ' ') {
					j--;
				}
				result[j] = inputArray[i];
				j--;
			}
		}
		System.out.println(String.valueOf(result));
	}

}
