package stringCoding;

public class Snake_Case_Of_A_Given_Sentence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "This is java Coding";
		char arr[] = str.toCharArray();

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == ' ')
				System.out.print("_");

			else
				System.out.print(arr[i]);
		}

	}

}
