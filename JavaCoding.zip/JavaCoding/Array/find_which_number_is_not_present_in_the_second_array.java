package Array;

import java.util.HashMap;

public class find_which_number_is_not_present_in_the_second_array {

	public static void find_which_number_is_not_present_in_second_array(int arr1[], int arr2[]) {

		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (int i = 0; i < arr1.length; i++) {

			map.put(arr1[i], 1);
		}

		for (int j = 0; j < arr2.length; j++) {

			if (!map.containsKey(arr2[j]))
				System.out.println(arr2[j]);
		}
	}

	public static void main(String args[]) {

		int arr1[] = { 1, 2, 3, 4, 5 };

		int arr2[] = { 0, 8, 2, 3, 5, 9 };

		find_which_number_is_not_present_in_second_array(arr1, arr2);
	}
}
