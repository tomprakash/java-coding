package stringCoding;

public class ReverseWordsOfAnString {

	public static void main(String[] args) {
		System.out.println(ReverseWords("My name is Tom Prakash"));
	}

	public static String ReverseWords(String str) {

		String ReverseWords = "";
		for (int i = str.length() - 1; i >= 0; i--) {

			ReverseWords = ReverseWords + str.charAt(i);

		}
		return ReverseWords;
	}

}
