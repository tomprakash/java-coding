package Array;

public class Merge_Two_Arrays {

	public static int[] mergingTwoArrays(int arr1[], int arr2[]) {
		int newarr[] = new int[arr1.length + arr2.length];
		int index =0;
		for (int i = 0; i < arr1.length; i++) {

			newarr[index] = arr1[i];
			index++;
		}

		for (int j = 0; j < arr2.length; j++) {

			newarr[index] = arr2[j];
			index++;
		}

		for (int k = 0; k < newarr.length; k++) {

			System.out.println(newarr[k]);
		}
		return newarr;
	}

	public static void main(String[] args) {

		int arr1[] = { 16,2,3,6,0,1,8 };
		int arr2[] = { 0, 4, 8, 11 };
		mergingTwoArrays(arr1, arr2);
	}
}
