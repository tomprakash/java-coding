package stringCoding;

public class String_containing_first_letter_of_every_word_in_a_given_string_with_spaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "geeks for geeks";

		String[] str1 = str.split(" ");

		StringBuffer s = new StringBuffer();

		for (int i = 0; i < str1.length; i++)

		{
			s = s.append(str1[i].charAt(0));
		}

		System.out.println(s);
	}

}
