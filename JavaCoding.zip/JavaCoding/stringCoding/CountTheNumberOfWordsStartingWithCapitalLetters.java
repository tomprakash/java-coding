package stringCoding;

public class CountTheNumberOfWordsStartingWithCapitalLetters {

	// Function to amend the sentence
	public static void CountWordsWithCapitalLetters(String sstr) {
		char[] str = sstr.toCharArray();
		int count = 1;
		// Traverse the string
		for (int i = 0; i < str.length; i++) {
			// Convert to lowercase if its
			// an uppercase character

			if (str[i] >= 'A' && str[i] <= 'Z') {
				str[i] = (char) (str[i] + 32);

				// Print space before it
				// if its an uppercase character
				if (i != 0) {
					System.out.print(" ");
					count++;
				}
				// Print the character
				System.out.print(str[i]);
			}

			// if lowercase character
			// then just print
			else
				System.out.print(str[i]);
		}
		System.out.println();
		System.out.println("count " + count);

	}

	// Driver Code
	public static void main(String[] args) {
		String str = "BruceWayneIsBatman";
		CountWordsWithCapitalLetters(str);

	}

}
