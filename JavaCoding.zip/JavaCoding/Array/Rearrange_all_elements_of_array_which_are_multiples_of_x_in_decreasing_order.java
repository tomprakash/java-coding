package Array;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Rearrange_all_elements_of_array_which_are_multiples_of_x_in_decreasing_order {

	public static void arrange_multiples_of_x_in_decreasing_order(int arr[], int x) {

		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < arr.length; i++) {

			if (arr[i] % x == 0) {

				list.add(arr[i]);
			}
		}

		System.out.println("ArrayList Before Sorting:");
		for (Integer i : list) {
			System.out.println(i);
		}

		/* Sorting in decreasing (descending) order */
		Collections.sort(list, Collections.reverseOrder());

		/* Sorted List in reverse order */
		System.out.println("ArrayList in descending order:");
		for (Integer i : list) {
			System.out.println(i);
		}
	}

	public static void main(String[] args) {

		int arr[] = { 5, 2, 10, 15, 20, 21 };
		arrange_multiples_of_x_in_decreasing_order(arr, 5);
	}

}
