package stringCoding;

public class IfStringHasAllUniqueCharacters {

	public static void main(String[] args)

	{
		String str = "Tomprakash";
		if (IsUniqueCharacter(str)) {
			System.out.println("String has all unique characters");
		} else {
			System.out.println("String does not have unique characters");
		}
	}

	static boolean IsUniqueCharacter(String str) {
		for (int i = 0; i < str.length(); i++) {
			for (int k = i + 1; k < str.length(); k++) {
				if (str.charAt(i) == str.charAt(k)) {
					return false;
				}
			}
		}

		return true;
	}
}
